from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
import json
import bcrypt

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    profile_pic = db.Column(db.String(500), default='')
    language = db.Column(db.String(20), default='english')
    theme = db.Column(db.String(20), default='purple')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    conversations = db.relationship(
        'Conversation', backref='user', lazy=True,
        cascade='all, delete-orphan'
    )

    def set_password(self, password):
        self.password = bcrypt.hashpw(
            password.encode('utf-8'),
            bcrypt.gensalt()
        ).decode('utf-8')

    def check_password(self, password):
        return bcrypt.checkpw(
            password.encode('utf-8'),
            self.password.encode('utf-8')
        )


class Conversation(db.Model):
    __tablename__ = 'conversations'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(
        db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), default='New Chat')
    messages = db.Column(db.Text, default='[]')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    def get_messages(self):
        return json.loads(self.messages)

    def set_messages(self, messages):
        self.messages = json.dumps(messages)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'messages': self.get_messages(),
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M')
        }