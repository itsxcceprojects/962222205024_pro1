import os
import re
import fitz
import zipfile


# ── Text Splitting ──
def split_text(text, chunk_size=500, overlap=50):
    chunks = []
    for i in range(0, len(text), chunk_size - overlap):
        chunk = text[i:i + chunk_size]
        if chunk.strip():
            chunks.append(chunk)
    return chunks


# ── Keyword Search ──
def find_relevant(question, chunks, top_k=3):
    words = [w for w in question.lower().split() if len(w) > 3]
    scored = []
    for chunk in chunks:
        score = sum(1 for w in words if w in chunk.lower())
        scored.append((score, chunk))
    scored.sort(reverse=True)
    return [c for _, c in scored[:top_k]]


# ── Request Type Detection ──
def is_summary_request(message):
    keywords = [
        'summarize', 'summary', 'overview',
        'about this', 'what is this book',
        'describe the book', 'main points',
        'key points', 'brief', 'synopsis',
        'outline', 'explain the book',
        'what happens', 'tell me about'
    ]
    return any(w in message.lower() for w in keywords)


def is_metadata_request(message):
    keywords = [
        'author', 'writer', 'written by',
        'who wrote', 'publisher', 'published',
        'year', 'edition', 'isbn',
        'title', 'name of the book',
        'who is the author', 'book name'
    ]
    return any(w in message.lower() for w in keywords)


def is_question(message):
    question_words = ['what', 'who', 'where', 'when',
                      'why', 'how', 'which', 'explain',
                      'describe', 'tell me']
    msg = message.lower().strip()
    return msg.endswith('?') or any(
        msg.startswith(w) for w in question_words)


# ── Smart Chunk Selection ──
def get_smart_chunks(message, chunks):
    if not chunks:
        return []

    if is_summary_request(message):
        # Spread chunks across entire document
        top_k = 12
        step = max(1, len(chunks) // top_k)
        selected = [chunks[i] for i in
                    range(0, len(chunks), step)][:top_k]
        return selected

    elif is_metadata_request(message):
        # Check beginning and end for metadata
        first = chunks[:4]
        last = chunks[-3:]
        keyword = find_relevant(message, chunks, top_k=3)
        seen = set()
        result = []
        for c in first + last + keyword:
            if c not in seen:
                seen.add(c)
                result.append(c)
        return result[:6]

    else:
        # Normal keyword search
        return find_relevant(message, chunks, top_k=4)


# ── Build Smart Prompt ──
def build_prompt(message, chunks):
    if not chunks:
        return message

    context = "\n\n---\n\n".join(chunks)

    if is_summary_request(message):
        return f"""You are a helpful book assistant.
The user has uploaded a document. Summarize it thoroughly.

Document Content:
{context}

Task: {message}

Write a comprehensive, well-structured summary covering:
- Main theme and purpose
- Key topics and ideas
- Important details
- Conclusion or outcome

Summary:"""

    elif is_metadata_request(message):
        return f"""You are a helpful book assistant.
Look carefully at this document content for author, title,
publisher, year and other metadata.

Document Content:
{context}

Question: {message}

Instructions:
- Search carefully in the content above
- If found state it clearly
- If not found in document use your own knowledge
  about this book if you recognize it
- Always give a helpful answer

Answer:"""

    else:
        return f"""You are a helpful document assistant.
Use the document content below to answer the question.
If the answer is in the document use it directly.
If not use your own knowledge to help.

Document Content:
{context}

Question: {message}

Answer:"""


# ── PDF Loading ──
def load_pdf(filepath):
    try:
        doc = fitz.open(filepath)
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()
        if not text.strip():
            return None, "PDF appears to be empty or scanned"
        chunks = split_text(text)
        return chunks, f"PDF loaded! {len(chunks)} chunks ready"
    except Exception as e:
        return None, f"Error loading PDF: {str(e)}"


# ── Ebook Loading ──
def load_ebook(filepath):
    ext = os.path.splitext(filepath)[1].lower()
    try:
        if ext == '.txt':
            with open(filepath, 'r', encoding='utf-8') as f:
                text = f.read()

        elif ext == '.epub':
            text = ""
            with zipfile.ZipFile(filepath) as z:
                # Sort files to maintain chapter order
                names = sorted([
                    n for n in z.namelist()
                    if n.endswith(('.html', '.xhtml', '.htm'))
                ])
                for name in names:
                    content = z.read(name).decode(
                        'utf-8', errors='ignore')
                    # Remove HTML tags
                    clean = re.sub(r'<[^>]+>', ' ', content)
                    # Remove extra spaces
                    clean = re.sub(r'\s+', ' ', clean).strip()
                    text += clean + "\n\n"
        else:
            with open(filepath, 'r',
                      encoding='utf-8', errors='ignore') as f:
                text = f.read()

        if not text.strip():
            return None, "File appears to be empty"

        chunks = split_text(text)
        return chunks, f"Loaded! {len(chunks)} chunks ready"

    except Exception as e:
        return None, f"Error loading file: {str(e)}"


# ── Get Document Info ──
def get_doc_info(chunks):
    if not chunks:
        return {}

    # Try to extract title and basic info from first chunks
    first_text = " ".join(chunks[:3])

    info = {
        "total_chunks": len(chunks),
        "estimated_pages": len(chunks) // 3,
        "first_preview": chunks[0][:200] if chunks else ""
    }
    return info