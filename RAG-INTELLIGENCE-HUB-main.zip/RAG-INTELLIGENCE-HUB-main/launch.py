import threading
import time
import requests
import subprocess
import sys
import os
import signal

os.chdir(os.path.dirname(os.path.abspath(__file__)))
FLASK_URL = "http://localhost:5000"


def kill_port(port):
    os.system(f"fuser -k {port}/tcp 2>/dev/null")
    time.sleep(1)


def wait_for_flask():
    for i in range(40):
        try:
            res = requests.get(FLASK_URL, timeout=2)
            if res.status_code in [200, 302]:
                print("✅ Backend ready!")
                return True
        except:
            pass
        print(f"⏳ Waiting... {i+1}/40")
        time.sleep(1)
    return False


def main():
    print("=" * 40)
    print("  JANS-HUB Study Hub")
    print("=" * 40)

    # Kill any existing process on port 5000
    print("Clearing port 5000...")
    kill_port(5000)

    # Set environment
    env = os.environ.copy()
    env['DBUS_SESSION_BUS_ADDRESS'] = 'disabled:'
    env['NO_AT_BRIDGE'] = '1'

    # Start Flask
    print("Starting backend...")
    flask_proc = subprocess.Popen(
        ["python3", "app.py"],
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )

    # Wait for Flask
    if not wait_for_flask():
        print("❌ Backend failed to start!")
        flask_proc.terminate()
        sys.exit(1)

    # Find best browser for app mode
    browsers = [
        "/usr/bin/brave-browser",
        "/usr/bin/brave",
        "/snap/bin/brave",
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
    ]

    browser = None
    for path in browsers:
        if os.path.exists(path):
            browser = path
            break

    if browser:
        print(f"🚀 Opening JANS-HUB as app...")
        app_proc = subprocess.Popen([
            browser,
            f"--app={FLASK_URL}",
            "--window-size=1400,900",
            "--disable-extensions",
            "--disable-plugins",
            "--no-first-run",
            "--disable-default-apps",
            "--disable-background-networking",
            "--disable-sync",
            "--disable-translate",
            "--disable-features=TranslateUI",
            "--process-per-site",
        ])
    else:
        print("Opening in default browser...")
        app_proc = subprocess.Popen(["xdg-open", FLASK_URL])

    print("✅ JANS-HUB is running!")
    print("Close the app window to stop")

    # Handle Ctrl+C
    def cleanup(sig, frame):
        print("\nStopping JANS-HUB...")
        try:
            app_proc.terminate()
        except:
            pass
        flask_proc.terminate()
        kill_port(5000)
        sys.exit(0)

    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    # Keep running until window closes
    try:
        flask_proc.wait()
    except KeyboardInterrupt:
        cleanup(None, None)


if __name__ == '__main__':
    main()