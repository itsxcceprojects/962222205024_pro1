import requests
import base64
import gc
import time
import os
from PIL import Image as PILImage

OLLAMA_URL = "http://localhost:11434"
VISION_MODEL = "gemma3:4b"
UPLOAD_FOLDER = "uploads"


def unload_all_models():
    models_to_unload = [
        "gemma3:4b",
        "gemma3-fast",
        "llava:13b",
        "llava:7b",
        "llava-phi3",
        "llama3.2-vision:11b",
        "deepseek-coder:6.7b",
        "phi3.5:latest",
        "llama3.2:3b",
        "qwen2.5vl:7b"
    ]
    for model in models_to_unload:
        try:
            requests.post(f"{OLLAMA_URL}/api/generate", json={
                "model": model,
                "keep_alive": 0
            }, timeout=5)
        except:
            pass
    print("All models unloaded!")


def unload_text_model(text_model):
    try:
        requests.post(f"{OLLAMA_URL}/api/generate", json={
            "model": text_model,
            "keep_alive": 0
        }, timeout=10)
        print(f"Unloaded {text_model}")
    except:
        pass


def unload_vision_model():
    try:
        requests.post(f"{OLLAMA_URL}/api/generate", json={
            "model": VISION_MODEL,
            "keep_alive": 0
        }, timeout=10)
        print(f"Unloaded {VISION_MODEL}")
    except:
        pass


def get_loaded_models():
    try:
        res = requests.get(f"{OLLAMA_URL}/api/ps", timeout=5)
        if res.ok:
            return res.json().get('models', [])
        return []
    except:
        return []


def free_ram_for_vision():
    print("Freeing ALL RAM for vision...")
    unload_all_models()
    gc.collect()
    print("Waiting for RAM to free...")

    # Wait until all models are unloaded
    for i in range(10):
        time.sleep(2)
        loaded = get_loaded_models()
        if not loaded:
            print(f"RAM freed after {(i+1)*2}s!")
            break
        else:
            print(f"Still loaded: {[m.get('name') for m in loaded]}")

    time.sleep(3)
    print("Ready for vision!")


def resize_image(image_path, max_size=(336, 336), quality=75):
    try:
        img = PILImage.open(image_path)
        img.thumbnail(max_size)
        img.save(image_path, quality=quality)
        return True
    except Exception as e:
        print(f"Resize failed: {e}")
        return False


def image_to_base64(image_path):
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode()


def build_vision_prompt(message, lang_prompt=""):
    if message:
        prompt = message
        if lang_prompt:
            prompt += " " + lang_prompt
        return prompt

    base_prompt = (
        "You are an expert historian and biographer with vast knowledge "
        "of famous scientists, politicians, artists, athletes and public figures. "
        "Look carefully at this person and identify them. "
        "Provide: Full name, birth/death dates, nationality, field of work, "
        "major achievements, famous discoveries or contributions, and their legacy. "
        "If you cannot identify the specific person, describe their appearance "
        "and any contextual clues about who they might be."
    )

    if lang_prompt:
        base_prompt += " " + lang_prompt

    return base_prompt


def process_image(
        image_file, message="", lang_prompt="", text_model="gemma3:4b"):

    # Save uploaded file
    image_path = os.path.join(UPLOAD_FOLDER, image_file.filename)
    image_file.save(image_path)

    # Free ALL RAM before vision
    free_ram_for_vision()

    # Resize image
    resize_image(image_path, max_size=(336, 336), quality=75)

    # Convert to base64
    img_b64 = image_to_base64(image_path)

    # Build prompt
    prompt = build_vision_prompt(message, lang_prompt)

    # Call vision model
    body = {
        "model": VISION_MODEL,
        "prompt": prompt,
        "images": [img_b64],
        "stream": False,
        "options": {
            "num_predict": 800,
            "num_ctx": 2048,
            "temperature": 0.1
        }
    }

    try:
        print(f"Running vision with {VISION_MODEL}...")
        res = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json=body,
            timeout=300
        )

        if res.ok:
            answer = res.json().get(
                "response", "Could not process image")
            unload_vision_model()
            return {
                "success": True,
                "answer": answer,
                "image_path": image_path
            }
        else:
            try:
                error_data = res.json()
                error_msg = error_data.get('error', res.text)
            except:
                error_msg = res.text
            print(f"Vision error: {error_msg}")
            return {
                "success": False,
                "error": error_msg
            }

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def is_vision_available():
    try:
        res = requests.get(
            f"{OLLAMA_URL}/api/tags", timeout=3)
        if res.ok:
            models = [m['name'] for m in res.json().get('models', [])]
            return VISION_MODEL in models
        return False
    except:
        return False


def get_vision_model():
    return VISION_MODEL


def set_vision_model(model_name):
    global VISION_MODEL
    VISION_MODEL = model_name