import torch
from diffusers import AutoPipelineForText2Image, LCMScheduler
from PIL import Image
import base64
import io
import os

# Use smallest fastest model
MODEL_ID = "SimianLuo/LCM_Dreamshaper_v7"
pipeline = None


def load_pipeline():
    global pipeline
    if pipeline is not None:
        return pipeline

    print("Loading image generation model...")
    pipeline = AutoPipelineForText2Image.from_pretrained(
        MODEL_ID,
        torch_dtype=torch.float32,
    )
    pipeline.scheduler = LCMScheduler.from_config(
        pipeline.scheduler.config)

    # CPU optimizations
    pipeline.enable_attention_slicing()
    print("Image model loaded!")
    return pipeline


def generate_image(prompt, width=512, height=512, steps=4):
    try:
        pipe = load_pipeline()

        # Add quality prompt
        full_prompt = f"{prompt}, high quality, detailed, beautiful"

        image = pipe(
            prompt=full_prompt,
            num_inference_steps=steps,
            guidance_scale=1.0,
            width=width,
            height=height,
        ).images[0]

        # Convert to base64
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        img_b64 = base64.b64encode(
            buffer.getvalue()).decode('utf-8')

        return {
            "success": True,
            "image": img_b64,
            "prompt": prompt
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def is_image_request(message):
    keywords = [
        'generate image', 'create image', 'draw',
        'make image', 'show image', 'generate a pic',
        'create a pic', 'give a pic', 'give me a pic',
        'show me a pic', 'generate picture',
        'create picture', 'make picture',
        'generate photo', 'create photo',
        'image of', 'picture of', 'photo of',
        'draw me', 'paint me', 'illustrate'
    ]
    msg = message.lower()
    return any(k in msg for k in keywords)