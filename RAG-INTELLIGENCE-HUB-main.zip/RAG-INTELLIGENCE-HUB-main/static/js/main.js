// ── Global State ──
let selectedImage = null;
let isRecording = false;
let mediaRecorder = null;
let audioChunks = [];
let agentMode = false;
let imageMode = false;
let currentConvId = null;
let currentProjectDir = "";
let currentAppName = "";
let currentHtmlFile = "";
let sessionId = "session_" + Math.random().toString(36).substr(2, 9);
let agentStartTime = null;
let timerInterval = null;
let currentTheme = 'purple';
let currentLanguage = 'english';

// Study state
let studyQuestionsFile = null;
let studyNotesFile = null;
let studyContentFile = null;
let currentQuizData = null;
let currentQuizIndex = 0;
let currentQuizScore = 0;
let currentFlashIndex = 0;
let flashcards = [];

// ── Translations ──
const TRANSLATIONS = {
    english: {
        newChat: 'New Chat',
        recentChats: 'Recent Chats',
        tools: 'Tools',
        uploadPdf: 'Upload PDF',
        uploadEbook: 'Upload Ebook',
        voiceInput: 'Voice Input',
        aiAgent: 'AI Agent',
        imageCreator: 'Image Creator',
        settings: 'Settings',
        studyTools: '📚 Study Tools',
        messagePlaceholder: 'Message JANS...',
        hint: 'Enter to send · Attach image · Use Study Tools →',
        welcomeTitle: "Hey, I'm JANS!",
        welcomeDesc: 'Your personal offline AI Study Hub.',
        agentOn: 'Agent Mode ON — describe an app to build',
        imageOn: 'Image Creator ON — describe what to generate'
    },
    tamil: {
        newChat: 'புதிய அரட்டை',
        recentChats: 'சமீபத்திய அரட்டைகள்',
        tools: 'கருவிகள்',
        uploadPdf: 'PDF பதிவேற்று',
        uploadEbook: 'புத்தகம் பதிவேற்று',
        voiceInput: 'குரல் உள்ளீடு',
        aiAgent: 'AI முகவர்',
        imageCreator: 'படம் உருவாக்கி',
        settings: 'அமைப்புகள்',
        studyTools: '📚 படிப்பு கருவிகள்',
        messagePlaceholder: 'JANS-க்கு செய்தி அனுப்பு...',
        hint: 'அனுப்ப Enter · படம் இணை · படிப்பு கருவிகள் →',
        welcomeTitle: "வணக்கம், நான் JANS!",
        welcomeDesc: 'உங்கள் தனிப்பட்ட offline AI படிப்பு மையம்.',
        agentOn: 'முகவர் முறை ON',
        imageOn: 'படம் உருவாக்கி ON'
    },
    hindi: {
        newChat: 'नई चैट',
        recentChats: 'हाल की चैट',
        tools: 'उपकरण',
        uploadPdf: 'PDF अपलोड',
        uploadEbook: 'ईबुक अपलोड',
        voiceInput: 'आवाज़ इनपुट',
        aiAgent: 'AI एजेंट',
        imageCreator: 'छवि निर्माता',
        settings: 'सेटिंग्स',
        studyTools: '📚 अध्ययन उपकरण',
        messagePlaceholder: 'JANS को संदेश भेजें...',
        hint: 'भेजने के लिए Enter · छवि संलग्न करें',
        welcomeTitle: "नमस्ते, मैं JANS हूँ!",
        welcomeDesc: 'आपका व्यक्तिगत offline AI अध्ययन केंद्र।',
        agentOn: 'एजेंट मोड ON',
        imageOn: 'छवि निर्माता ON'
    }
};

function t(key) {
    return TRANSLATIONS[currentLanguage]?.[key] ||
        TRANSLATIONS.english[key] || key;
}

function applyTranslations() {
    const msgInput = document.getElementById('message-input');
    if (msgInput) msgInput.placeholder = t('messagePlaceholder');
}

// ── Theme System ──
const THEMES = {
    purple: { primary: '#667eea', secondary: '#764ba2', glow: 'rgba(102,126,234,0.15)' },
    blue: { primary: '#0ea5e9', secondary: '#2563eb', glow: 'rgba(14,165,233,0.15)' },
    green: { primary: '#10b981', secondary: '#059669', glow: 'rgba(16,185,129,0.15)' },
    red: { primary: '#f43f5e', secondary: '#e11d48', glow: 'rgba(244,63,94,0.15)' },
    orange: { primary: '#f97316', secondary: '#ea580c', glow: 'rgba(249,115,22,0.15)' },
    pink: { primary: '#ec4899', secondary: '#db2777', glow: 'rgba(236,72,153,0.15)' },
    teal: { primary: '#14b8a6', secondary: '#0d9488', glow: 'rgba(20,184,166,0.15)' },
    gold: { primary: '#f59e0b', secondary: '#d97706', glow: 'rgba(245,158,11,0.15)' }
};

function applyTheme(theme) {
    currentTheme = theme;
    const th = THEMES[theme] || THEMES.purple;
    const root = document.documentElement;
    root.style.setProperty('--primary', th.primary);
    root.style.setProperty('--secondary', th.secondary);
    root.style.setProperty('--glow', th.glow);
    root.style.setProperty('--btn-gradient',
        `linear-gradient(135deg, ${th.primary}, ${th.secondary})`);
    document.body.className = `theme-${theme}`;
}

// ── Init ──
window.addEventListener('load', () => {
    const cfg = window.JANS_CONFIG || {};
    currentTheme = cfg.theme || 'purple';
    currentLanguage = cfg.language || 'english';
    applyTheme(currentTheme);
    applyTranslations();
    checkStatus();
    loadChatHistory();
    updateSettingsUI();
    initResizableSidebar();
});

// ── Socket.IO ──
const socket = io();
socket.on('terminal_output', (data) => appendTerminal(data.data));
socket.on('app_finished', () => {
    const btn = document.getElementById('stop-btn');
    if (btn) btn.style.opacity = '0.4';
});

// ── Status ──
async function checkStatus() {
    try {
        const res = await fetch("/status");
        const data = await res.json();
        const dot = document.getElementById("status-dot");
        if (data.ready) dot.classList.add("ready");
        else { dot.classList.remove("ready"); setTimeout(checkStatus, 3000); }
    } catch { setTimeout(checkStatus, 3000); }
}

// ── Chat History ──
async function loadChatHistory() {
    try {
        const res = await fetch('/api/conversations');
        const convs = await res.json();
        const container = document.getElementById('chat-history');
        container.innerHTML = '';
        if (convs.length === 0) {
            container.innerHTML = '<p style="color:rgba(255,255,255,0.2);font-size:0.75rem;padding:0.4rem 0.75rem">No conversations yet</p>';
            return;
        }
        convs.forEach(conv => {
            const item = document.createElement('div');
            item.className = 'history-item' + (conv.id === currentConvId ? ' active' : '');
            item.dataset.id = conv.id;
            item.innerHTML = `
                <span class="history-title">${conv.title}</span>
                <button class="history-del" onclick="deleteConv(${conv.id},event)">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>`;
            item.addEventListener('click', () => loadConversation(conv.id));
            container.appendChild(item);
        });
    } catch (e) { console.error(e); }
}

async function loadConversation(convId) {
    try {
        const res = await fetch(`/api/conversations/${convId}`);
        const conv = await res.json();
        currentConvId = convId;
        document.querySelectorAll('.history-item').forEach(item => {
            item.classList.toggle('active', parseInt(item.dataset.id) === convId);
        });
        const welcome = document.getElementById('welcome');
        const messages = document.getElementById('messages');
        welcome.style.display = 'none';
        messages.style.display = 'flex';
        messages.innerHTML = '';
        conv.messages.filter(m => m.role !== 'system').forEach(msg => {
            if (msg.content && msg.content.startsWith('[Generated image')) return;
            addMessage(msg.role === 'user' ? 'user' : 'assistant', msg.content);
        });
    } catch (e) { console.error(e); }
}

async function deleteConv(convId, event) {
    event.stopPropagation();
    try {
        await fetch(`/api/conversations/${convId}`, { method: 'DELETE' });
        if (currentConvId === convId) {
            currentConvId = null;
            document.getElementById('messages').innerHTML = '';
            document.getElementById('messages').style.display = 'none';
            document.getElementById('welcome').style.display = 'flex';
        }
        loadChatHistory();
    } catch (e) { console.error(e); }
}

function newChat() {
    currentConvId = null;
    document.getElementById('messages').innerHTML = '';
    document.getElementById('messages').style.display = 'none';
    document.getElementById('welcome').style.display = 'flex';
    document.querySelectorAll('.history-item').forEach(i => i.classList.remove('active'));
    document.getElementById('message-input').focus();
}

// ── Reset Modes ──
function resetAllModes() {
    agentMode = false;
    imageMode = false;
    const agentBtn = document.getElementById("agent-btn");
    const imageBtn = document.getElementById("image-btn");
    if (agentBtn) { agentBtn.style.background = ""; agentBtn.style.borderColor = ""; agentBtn.style.color = ""; }
    if (imageBtn) { imageBtn.style.background = ""; imageBtn.style.borderColor = ""; imageBtn.style.color = ""; }
    const agentStatus = document.getElementById("agent-status");
    const imageStatus = document.getElementById("image-btn-status");
    if (agentStatus) agentStatus.textContent = t('aiAgent');
    if (imageStatus) imageStatus.textContent = t('imageCreator');
    document.getElementById("agent-indicator").style.display = "none";
    document.getElementById("image-indicator").style.display = "none";
    document.getElementById("message-input").placeholder = t('messagePlaceholder');
}

// ── Format Text ──
function formatText(text) {
    return text
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(/^## (.+)$/gm, '<h4 style="color:var(--primary);margin:0.75rem 0 0.25rem;font-family:Syne,sans-serif">$1</h4>')
        .replace(/^# (.+)$/gm, '<h3 style="color:var(--primary);margin:0.75rem 0 0.25rem;font-family:Syne,sans-serif">$1</h3>')
        .replace(/^\* (.+)$/gm, '<li style="margin-left:1rem;margin-bottom:0.2rem;list-style:none"><span style="color:var(--primary);margin-right:0.4rem">•</span>$1</li>')
        .replace(/^- (.+)$/gm, '<li style="margin-left:1rem;margin-bottom:0.2rem;list-style:none"><span style="color:var(--primary);margin-right:0.4rem">•</span>$1</li>')
        .replace(/\n/g, '<br>');
}

// ── Add Message ──
function addMessage(role, text, mode, imageData) {
    const welcome = document.getElementById("welcome");
    const messages = document.getElementById("messages");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";

    const msg = document.createElement("div");
    msg.className = "msg " + role;
    const avatar = document.createElement("div");
    avatar.className = "avatar " + (role === "user" ? "user-avatar" : "ai-avatar");
    avatar.textContent = role === "user" ? "U" : "J";
    const bubble = document.createElement("div");
    bubble.className = "bubble";

    if (mode && mode !== 'text') {
        const badge = document.createElement("span");
        badge.className = "mode-badge";
        badge.textContent = mode === "vision" ? "vision" :
            mode === "agent" ? "agent" :
            mode === "rag" ? "doc" :
            mode === "image" ? "image" : mode;
        bubble.appendChild(badge);
        bubble.appendChild(document.createElement("br"));
    }

    if (imageData) {
        const img = document.createElement("img");
        img.src = `data:image/png;base64,${imageData}`;
        img.style.cssText = "max-width:100%;border-radius:12px;margin-top:0.5rem;display:block;cursor:pointer;";
        img.onclick = () => { const a = document.createElement('a'); a.href = img.src; a.download = 'generated.png'; a.click(); };
        bubble.appendChild(img);
        bubble.appendChild(document.createElement("br"));
    }

    const p = document.createElement("p");
    p.style.whiteSpace = "pre-wrap";
    p.textContent = text;
    bubble.appendChild(p);
    msg.appendChild(avatar);
    msg.appendChild(bubble);
    messages.appendChild(msg);
    messages.scrollTop = messages.scrollHeight;
}

// ── Add Image Message (shows uploaded image in chat) ──
function addImageMessage(role, text, imageUrl) {
    const messages = document.getElementById("messages");
    const welcome = document.getElementById("welcome");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";

    const msg = document.createElement("div");
    msg.className = "msg " + role;
    const avatar = document.createElement("div");
    avatar.className = "avatar user-avatar";
    avatar.textContent = "U";
    const bubble = document.createElement("div");
    bubble.className = "bubble";

    const img = document.createElement("img");
    img.src = imageUrl;
    img.style.cssText = "max-width:220px;max-height:220px;border-radius:10px;display:block;margin-bottom:0.5rem;object-fit:cover;box-shadow:0 4px 15px rgba(0,0,0,0.3);";
    bubble.appendChild(img);

    if (text && text !== "Describe this image") {
        const p = document.createElement("p");
        p.style.whiteSpace = "pre-wrap";
        p.textContent = text;
        bubble.appendChild(p);
    }

    msg.appendChild(avatar);
    msg.appendChild(bubble);
    messages.appendChild(msg);
    messages.scrollTop = messages.scrollHeight;
}

// ── Add Formatted Message (for vision responses) ──
function addFormattedMessage(role, text, mode) {
    const messages = document.getElementById("messages");
    const welcome = document.getElementById("welcome");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";

    const msg = document.createElement("div");
    msg.className = "msg " + role;
    const avatar = document.createElement("div");
    avatar.className = "avatar ai-avatar";
    avatar.textContent = "J";
    const bubble = document.createElement("div");
    bubble.className = "bubble";

    if (mode) {
        const badge = document.createElement("span");
        badge.className = "mode-badge";
        badge.textContent = mode;
        bubble.appendChild(badge);
        bubble.appendChild(document.createElement("br"));
    }

    const content = document.createElement("div");
    content.className = "formatted-content";
    content.innerHTML = formatText(text);
    bubble.appendChild(content);

    msg.appendChild(avatar);
    msg.appendChild(bubble);
    messages.appendChild(msg);
    messages.scrollTop = messages.scrollHeight;
}

function addLoadingBubble() {
    const messages = document.getElementById("messages");
    const welcome = document.getElementById("welcome");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";
    const msg = document.createElement("div");
    msg.className = "msg assistant"; msg.id = "loading-msg";
    const avatar = document.createElement("div");
    avatar.className = "avatar ai-avatar"; avatar.textContent = "J";
    const bubble = document.createElement("div");
    bubble.className = "loading-bubble";
    bubble.innerHTML = '<span class="dot"></span><span class="dot"></span><span class="dot"></span>';
    msg.appendChild(avatar); msg.appendChild(bubble);
    messages.appendChild(msg); messages.scrollTop = messages.scrollHeight;
}

function removeLoadingBubble() {
    const el = document.getElementById("loading-msg");
    if (el) el.remove();
}

function addStreamingBubble() {
    const messages = document.getElementById("messages");
    const welcome = document.getElementById("welcome");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";
    const msg = document.createElement("div");
    msg.className = "msg assistant";
    const avatar = document.createElement("div");
    avatar.className = "avatar ai-avatar"; avatar.textContent = "J";
    const bubble = document.createElement("div");
    bubble.className = "bubble streaming";
    const p = document.createElement("p");
    p.style.whiteSpace = "pre-wrap";
    const cursor = document.createElement("span");
    cursor.className = "cursor"; cursor.textContent = "▋";
    bubble.appendChild(p); bubble.appendChild(cursor);
    msg.appendChild(avatar); msg.appendChild(bubble);
    messages.appendChild(msg); messages.scrollTop = messages.scrollHeight;
    return { msg, p, cursor, bubble };
}

function updateStreamingBubble(obj, text) {
    obj.p.textContent = text;
    document.getElementById("messages").scrollTop = 99999;
}

function finalizeStreamingBubble(obj, mode) {
    if (obj.cursor) obj.cursor.remove();
    obj.bubble.classList.remove('streaming');
    if (mode && mode !== 'text') {
        const badge = document.createElement("span");
        badge.className = "mode-badge";
        badge.textContent = mode === "rag" ? "doc" : mode;
        obj.bubble.insertBefore(badge, obj.bubble.firstChild);
        obj.bubble.insertBefore(document.createElement("br"), obj.p);
    }
}

function showImageLoadingBubble() {
    const messages = document.getElementById("messages");
    const welcome = document.getElementById("welcome");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";
    const msg = document.createElement("div");
    msg.className = "msg assistant"; msg.id = "image-loading-msg";
    const avatar = document.createElement("div");
    avatar.className = "avatar ai-avatar"; avatar.textContent = "J";
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.innerHTML = `<span class="mode-badge">image</span><br>
        <div style="display:flex;align-items:center;gap:0.75rem;padding:0.5rem 0">
            <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#f093fb,#f5576c);display:flex;align-items:center;justify-content:center;font-size:1.4rem">🎨</div>
            <div><div style="font-size:0.9rem;color:rgba(255,255,255,0.8)">Generating image...</div>
            <div style="font-size:0.78rem;color:rgba(255,255,255,0.4)">May take 1-3 minutes</div></div>
            <div style="display:flex;gap:0.3rem;margin-left:auto">
                <span class="dot"></span><span class="dot" style="animation-delay:0.2s"></span><span class="dot" style="animation-delay:0.4s"></span>
            </div></div>`;
    msg.appendChild(avatar); msg.appendChild(bubble);
    messages.appendChild(msg); messages.scrollTop = messages.scrollHeight;
}

function removeImageLoadingBubble() {
    const el = document.getElementById("image-loading-msg");
    if (el) el.remove();
}

function showLoadingScreen(request) {
    const messages = document.getElementById("messages");
    const welcome = document.getElementById("welcome");
    if (welcome) welcome.style.display = "none";
    messages.style.display = "flex";
    const div = document.createElement("div");
    div.id = "agent-loading";
    div.style.cssText = "display:flex;flex-direction:column;align-items:center;justify-content:center;padding:3rem 2rem;text-align:center;width:100%";
    div.innerHTML = `
        <div style="width:72px;height:72px;border-radius:50%;background:var(--btn-gradient);display:flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:800;margin-bottom:1.5rem;box-shadow:0 0 30px var(--glow);color:white">J</div>
        <h2 style="background:var(--btn-gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:1.3rem;margin-bottom:0.5rem">Building Your App</h2>
        <p style="color:rgba(255,255,255,0.4);font-size:0.85rem;margin-bottom:2rem">${request}</p>
        <div style="width:280px;background:rgba(255,255,255,0.05);border-radius:100px;height:5px;margin-bottom:1.5rem;overflow:hidden">
            <div id="progress-bar" style="height:100%;width:0%;background:var(--btn-gradient);border-radius:100px;transition:width 0.5s ease"></div>
        </div>
        <div id="loading-step" style="color:rgba(255,255,255,0.5);font-size:0.82rem;margin-bottom:1rem">Initializing...</div>
        <div style="color:rgba(255,255,255,0.25);font-size:0.78rem">Elapsed: <span id="elapsed-time">0s</span></div>
        <div style="display:flex;gap:0.5rem;margin-top:2rem">
            <div class="dot"></div><div class="dot" style="animation-delay:0.2s"></div><div class="dot" style="animation-delay:0.4s"></div>
        </div>`;
    messages.appendChild(div); messages.scrollTop = messages.scrollHeight;
    agentStartTime = Date.now();
    timerInterval = setInterval(() => {
        const el = document.getElementById("elapsed-time");
        if (el) el.textContent = Math.floor((Date.now() - agentStartTime) / 1000) + "s";
    }, 1000);
    [
        { pct: 10, text: "Understanding request...", delay: 500 },
        { pct: 30, text: "Designing layout...", delay: 4000 },
        { pct: 55, text: "Writing code...", delay: 12000 },
        { pct: 75, text: "Adding features...", delay: 25000 },
        { pct: 90, text: "Almost ready...", delay: 50000 }
    ].forEach(s => setTimeout(() => {
        const bar = document.getElementById("progress-bar");
        const step = document.getElementById("loading-step");
        if (bar) bar.style.width = s.pct + "%";
        if (step) step.textContent = s.text;
    }, s.delay));
}

function removeLoadingScreen() {
    clearInterval(timerInterval);
    const el = document.getElementById("agent-loading");
    if (el) el.remove();
}

// ── Send Message ──
async function sendMessage() {
    const input = document.getElementById("message-input");
    const message = input.value.trim();
    if (!message && !selectedImage) return;
    input.value = "";

    // Vision — show image in chat first
   // Vision — show image in chat + stream response
    if (selectedImage) {
        const imageUrl = URL.createObjectURL(selectedImage);
        addImageMessage("user", message || "Describe this image", imageUrl);

        const fd = new FormData();
        fd.append("message", message);
        if (currentConvId) fd.append("conv_id", currentConvId);
        fd.append("image", selectedImage);
        removeImage();

        // Add streaming bubble for vision
        const visionBubble = addStreamingBubble();

        try {
            const res = await fetch("/chat", { method: "POST", body: fd });
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buffer = "";
            let fullText = "";

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split("\n");
                buffer = lines.pop();

                for (const line of lines) {
                    if (line.startsWith("data: ")) {
                        try {
                            const data = JSON.parse(line.slice(6));

                            if (data.token) {
                                fullText += data.token;
                                updateStreamingBubble(visionBubble, fullText);
                            }

                            if (data.done) {
                                // Finalize with formatted text
                                visionBubble.cursor.remove();
                                visionBubble.bubble.classList.remove('streaming');
                                const badge = document.createElement("span");
                                badge.className = "mode-badge";
                                badge.textContent = "vision";
                                visionBubble.bubble.insertBefore(
                                    badge, visionBubble.bubble.firstChild);
                                visionBubble.bubble.insertBefore(
                                    document.createElement("br"), visionBubble.p);

                                // Format the final text
                                const formattedDiv = document.createElement("div");
                                formattedDiv.className = "formatted-content";
                                formattedDiv.innerHTML = formatText(fullText);
                                visionBubble.bubble.replaceChild(
                                    formattedDiv, visionBubble.p);

                                currentConvId = data.conv_id;
                                loadChatHistory();
                            }

                            if (data.error) {
                                updateStreamingBubble(
                                    visionBubble, "Error: " + data.error);
                                finalizeStreamingBubble(visionBubble, null);
                            }
                        } catch {}
                    }
                }
            }
        } catch (e) {
            updateStreamingBubble(visionBubble, "Error: " + e.message);
            finalizeStreamingBubble(visionBubble, null);
        }
        return;
    }

    // Normal text message
    addMessage("user", message);

    // Text streaming
    const bubbleObj = addStreamingBubble();
    const fd = new FormData();
    fd.append("message", message);
    if (currentConvId) fd.append("conv_id", currentConvId);

    try {
        const res = await fetch("/chat", { method: "POST", body: fd });
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "", fullText = "", finalMode = "text";

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop();
            for (const line of lines) {
                if (line.startsWith("data: ")) {
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.token) { fullText += data.token; updateStreamingBubble(bubbleObj, fullText); }
                        if (data.done) { finalMode = data.mode || "text"; currentConvId = data.conv_id; finalizeStreamingBubble(bubbleObj, finalMode); loadChatHistory(); }
                        if (data.error) { updateStreamingBubble(bubbleObj, "Error: " + data.error); finalizeStreamingBubble(bubbleObj, null); }
                    } catch {}
                }
            }
        }
    } catch (e) { updateStreamingBubble(bubbleObj, "Error: " + e.message); finalizeStreamingBubble(bubbleObj, null); }
}

// ── Image Mode ──
function activateImageMode() {
    const wasActive = imageMode;
    resetAllModes();
    if (!wasActive) {
        imageMode = true;
        const btn = document.getElementById("image-btn");
        btn.style.background = "rgba(240,147,251,0.3)";
        btn.style.borderColor = "rgba(240,147,251,0.5)";
        document.getElementById("image-btn-status").textContent = "Image ON";
        document.getElementById("image-indicator").style.display = "block";
        document.getElementById("message-input").placeholder = "Describe image to generate...";
    }
}

async function runImageGeneration() {
    const input = document.getElementById("message-input");
    const prompt = input.value.trim();
    if (!prompt) return;
    input.value = "";
    addMessage("user", "Generate: " + prompt);
    showImageLoadingBubble();
    const fd = new FormData();
    fd.append("message", "create image of " + prompt);
    if (currentConvId) fd.append("conv_id", currentConvId);
    try {
        const res = await fetch("/chat", { method: "POST", body: fd });
        const data = await res.json();
        removeImageLoadingBubble();
        if (data.error) addMessage("assistant", "Error: " + data.error);
        else if (data.image) {
            addMessage("assistant", data.answer, "image", data.image);
            if (data.conv_id) { currentConvId = data.conv_id; loadChatHistory(); }
        } else addMessage("assistant", data.answer, data.mode);
    } catch (e) { removeImageLoadingBubble(); addMessage("assistant", "Error: " + e.message); }
}

function enableImageAndSend(text) {
    activateImageMode();
    document.getElementById("message-input").value = text;
    setTimeout(() => runImageGeneration(), 100);
}

// ── Agent Mode ──
function activateAgent() {
    const wasActive = agentMode;
    resetAllModes();
    if (!wasActive) {
        agentMode = true;
        const btn = document.getElementById("agent-btn");
        btn.style.background = "rgba(99,102,241,0.3)";
        btn.style.borderColor = "rgba(99,102,241,0.5)";
        document.getElementById("agent-status").textContent = "Agent ON";
        document.getElementById("agent-indicator").style.display = "block";
        document.getElementById("message-input").placeholder = "Describe an app to build...";
    }
}

function enableAgentAndSend(text) {
    activateAgent();
    document.getElementById("message-input").value = text;
    setTimeout(() => runAgent(), 100);
}

async function runAgent() {
    const input = document.getElementById("message-input");
    const request = input.value.trim();
    if (!request) return;
    input.value = "";
    addMessage("user", "Build: " + request);
    showLoadingScreen(request);
    try {
        const res = await fetch("/agent", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ request })
        });
        const data = await res.json();
        removeLoadingScreen();
        if (data.error) { addMessage("assistant", "Agent error: " + data.error); return; }
        currentProjectDir = data.project_dir;
        currentHtmlFile = data.html_file || "";
        currentAppName = data.files[0]?.replace('.html', '') || 'myapp';
        const elapsed = Math.floor((Date.now() - agentStartTime) / 1000);
        addFormattedMessage("assistant",
            `**App Created in ${elapsed}s!**\n\n- Lines of code: ${data.total_lines}\n- Status: ${data.status}\n\nYour app is now open! Desktop shortcut created.`,
            "agent");
        if (data.html_file) showHtmlPreview(data.html_file, request);
    } catch (e) { removeLoadingScreen(); addMessage("assistant", "Agent failed: " + e.message); }
}

function handleSend() {
    if (agentMode) runAgent();
    else if (imageMode) runImageGeneration();
    else sendMessage();
}

function sendSuggestion(text) {
    document.getElementById("message-input").value = text;
    handleSend();
}

// ══════════════════════════════════════
// ── RIGHT SIDEBAR STUDY TOOLS ──
// ══════════════════════════════════════

function openRightPanel(tool) {
    const panel = document.getElementById('right-study-panel');
    const body = document.getElementById('right-panel-body');
    const title = document.getElementById('right-panel-title');

    document.querySelectorAll('.right-tool-btn').forEach(b => b.classList.remove('active-rt'));

    const btnMap = {
        'qa': 'rt-qa', 'quiz': 'rt-quiz',
        'flashcards': 'rt-flash', 'notes': 'rt-notes',
        'math': 'rt-math', 'citation': 'rt-cite', 'code': 'rt-code'
    };
    const activeBtn = document.getElementById(btnMap[tool]);
    if (activeBtn) activeBtn.classList.add('active-rt');

    panel.style.display = 'flex';

    if (tool === 'qa') {
        title.textContent = '❓ Q&A Generator';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Upload question paper + notes PDF. Type which questions to answer.</p>
                <div class="study-upload-row">
                    <div class="study-upload-box" onclick="document.getElementById('q-file').click()">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        <span id="q-label">Questions PDF</span>
                        <input type="file" id="q-file" accept=".pdf" style="display:none" onchange="uploadStudyFile('q-file','q-label','questions','studyQuestionsFile')">
                    </div>
                    <div class="study-upload-box" onclick="document.getElementById('n-file').click()">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                        <span id="n-label">Notes PDF</span>
                        <input type="file" id="n-file" accept=".pdf" style="display:none" onchange="uploadStudyFile('n-file','n-label','notes','studyNotesFile')">
                    </div>
                </div>
                <div style="display:flex;gap:0.5rem;margin-bottom:0.75rem">
                    <input type="text" id="qa-instruction" placeholder='e.g. questions 1 to 6 or all' class="study-input" style="flex:1">
                    <button class="study-run-btn" onclick="runQA()">Generate</button>
                </div>
                <div id="qa-output" class="study-output"></div>
            </div>`;

    } else if (tool === 'quiz') {
        title.textContent = '📝 Quiz Maker';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Upload a PDF and generate MCQ questions to test yourself!</p>
                <div class="study-upload-box" onclick="document.getElementById('quiz-file').click()" style="margin-bottom:0.75rem">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    <span id="quiz-file-label">Upload PDF</span>
                    <input type="file" id="quiz-file" accept=".pdf" style="display:none" onchange="uploadStudyFile('quiz-file','quiz-file-label','content','studyContentFile')">
                </div>
                <div style="display:flex;gap:0.5rem;align-items:center;margin-bottom:0.75rem">
                    <label style="color:rgba(255,255,255,0.5);font-size:0.82rem">Questions:</label>
                    <select id="quiz-count" class="study-input" style="width:70px">
                        <option>5</option><option selected>10</option><option>15</option><option>20</option>
                    </select>
                    <button class="study-run-btn" onclick="runQuiz()">Generate Quiz</button>
                </div>
                <div id="quiz-output" class="study-output"></div>
            </div>`;

    } else if (tool === 'flashcards') {
        title.textContent = '🃏 Flashcards';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Upload notes and create interactive flashcards!</p>
                <div class="study-upload-box" onclick="document.getElementById('flash-file').click()" style="margin-bottom:0.75rem">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    <span id="flash-file-label">Upload PDF</span>
                    <input type="file" id="flash-file" accept=".pdf" style="display:none" onchange="uploadStudyFile('flash-file','flash-file-label','content','studyContentFile')">
                </div>
                <div style="display:flex;gap:0.5rem;align-items:center;margin-bottom:0.75rem">
                    <label style="color:rgba(255,255,255,0.5);font-size:0.82rem">Cards:</label>
                    <select id="flash-count" class="study-input" style="width:70px">
                        <option>10</option><option selected>15</option><option>20</option>
                    </select>
                    <button class="study-run-btn" onclick="runFlashcards()">Make Cards</button>
                </div>
                <div id="flash-output" class="study-output"></div>
            </div>`;

    } else if (tool === 'notes') {
        title.textContent = '📋 Smart Notes';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Upload any PDF and get structured study notes!</p>
                <div class="study-upload-box" onclick="document.getElementById('notes-file').click()" style="margin-bottom:0.75rem">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    <span id="notes-file-label">Upload PDF</span>
                    <input type="file" id="notes-file" accept=".pdf" style="display:none" onchange="uploadStudyFile('notes-file','notes-file-label','content','studyContentFile')">
                </div>
                <div style="display:flex;gap:0.5rem;margin-bottom:0.75rem">
                    <input type="text" id="notes-topic" placeholder="Optional topic focus" class="study-input" style="flex:1">
                    <button class="study-run-btn" onclick="runNotes()">Generate</button>
                </div>
                <div id="notes-output" class="study-output"></div>
            </div>`;

    } else if (tool === 'math') {
        title.textContent = '🔢 Math Solver';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Type any math problem for step-by-step solution!</p>
                <textarea id="math-input" class="study-textarea" placeholder="e.g. Solve: 2x + 5 = 15&#10;Find derivative of x^3 + 2x^2"></textarea>
                <button class="study-run-btn" style="width:100%;margin-bottom:0.75rem" onclick="runMath()">Solve Step by Step</button>
                <div id="math-output" class="study-output"></div>
            </div>`;

    } else if (tool === 'citation') {
        title.textContent = '📖 Citation Tool';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Generate APA, MLA or Chicago citations!</p>
                <textarea id="cite-input" class="study-textarea" placeholder="Author: John Smith&#10;Title: Introduction to Physics&#10;Year: 2023&#10;Publisher: Oxford Press"></textarea>
                <div style="display:flex;gap:0.5rem;margin-bottom:0.75rem">
                    <select id="cite-style" class="study-input" style="width:100px">
                        <option>APA</option><option>MLA</option><option>Chicago</option>
                    </select>
                    <button class="study-run-btn" style="flex:1" onclick="runCitation()">Generate</button>
                </div>
                <div id="cite-output" class="study-output"></div>
            </div>`;

    } else if (tool === 'code') {
        title.textContent = '💻 Code Tutor';
        body.innerHTML = `
            <div class="study-form">
                <p class="study-desc">Powered by DeepSeek — explain, fix or generate code!</p>
                <div style="display:flex;gap:0.4rem;margin-bottom:0.75rem;flex-wrap:wrap">
                    <button class="code-tab active-tab" id="tab-explain" onclick="switchCodeTab('explain')">Explain</button>
                    <button class="code-tab" id="tab-fix" onclick="switchCodeTab('fix')">Fix</button>
                    <button class="code-tab" id="tab-generate" onclick="switchCodeTab('generate')">Generate</button>
                </div>
                <div id="code-explain-panel">
                    <textarea id="code-input" class="study-textarea" placeholder="Paste your code here..."></textarea>
                    <input type="text" id="code-question" class="study-input" placeholder="Question about code (optional)">
                    <button class="study-run-btn" style="width:100%;margin-top:0.5rem" onclick="runCode('explain')">Explain Code</button>
                </div>
                <div id="code-fix-panel" style="display:none">
                    <textarea id="fix-input" class="study-textarea" placeholder="Paste buggy code..."></textarea>
                    <input type="text" id="fix-error" class="study-input" placeholder="Error message (optional)">
                    <button class="study-run-btn" style="width:100%;margin-top:0.5rem" onclick="runCode('fix')">Fix Code</button>
                </div>
                <div id="code-generate-panel" style="display:none">
                    <textarea id="gen-input" class="study-textarea" placeholder="Describe what code you want..."></textarea>
                    <div style="display:flex;gap:0.5rem;margin-top:0.5rem">
                        <select id="gen-language" class="study-input" style="width:120px">
                            <option>python</option><option>javascript</option><option>java</option><option>c++</option>
                        </select>
                        <button class="study-run-btn" style="flex:1" onclick="runCode('generate')">Generate</button>
                    </div>
                </div>
                <div id="code-output" class="study-output"></div>
            </div>`;
    }
}

function closeRightPanel() {
    document.getElementById('right-study-panel').style.display = 'none';
    document.querySelectorAll('.right-tool-btn').forEach(b => b.classList.remove('active-rt'));
}

function switchCodeTab(tab) {
    ['explain', 'fix', 'generate'].forEach(t => {
        document.getElementById(`tab-${t}`).classList.toggle('active-tab', t === tab);
        document.getElementById(`code-${t}-panel`).style.display = t === tab ? 'block' : 'none';
    });
}

async function uploadStudyFile(inputId, labelId, type, varName) {
    const fileInput = document.getElementById(inputId);
    const file = fileInput.files[0];
    if (!file) return;
    document.getElementById(labelId).textContent = 'Uploading...';
    const fd = new FormData();
    fd.append('file', file);
    fd.append('type', type);
    try {
        const res = await fetch('/study/upload', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            if (varName === 'studyQuestionsFile') studyQuestionsFile = data.filename;
            else if (varName === 'studyNotesFile') studyNotesFile = data.filename;
            else if (varName === 'studyContentFile') studyContentFile = data.filename;
            document.getElementById(labelId).textContent = '✅ ' + file.name;
        } else {
            document.getElementById(labelId).textContent = '❌ ' + (data.error || 'Failed');
        }
    } catch (e) {
        document.getElementById(labelId).textContent = '❌ Error';
    }
}

function showStudyLoading(outputId, msg) {
    document.getElementById(outputId).innerHTML = `
        <div class="study-loading">
            <span class="dot"></span><span class="dot" style="animation-delay:0.2s"></span><span class="dot" style="animation-delay:0.4s"></span>
            <span style="margin-left:0.5rem;color:rgba(255,255,255,0.5);font-size:0.82rem">${msg}</span>
        </div>`;
}

async function runQA() {
    if (!studyQuestionsFile || !studyNotesFile) { alert('Please upload both PDFs first!'); return; }
    const instruction = document.getElementById('qa-instruction').value || 'all';
    showStudyLoading('qa-output', 'Generating answers...');
    try {
        const res = await fetch('/study/qa', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ questions_file: studyQuestionsFile, notes_file: studyNotesFile, instruction })
        });
        const data = await res.json();
        const out = document.getElementById('qa-output');
        if (!data.success) { out.innerHTML = `<p style="color:#f87171">${data.error}</p>`; return; }
        let html = `<div class="qa-header">✅ ${data.total} Q&A pairs generated</div>`;
        data.qa_pairs.forEach(qa => {
            html += `
                <div class="qa-item">
                    <div class="qa-question">
                        <span class="qa-num">Q${qa.number}</span>
                        <span class="qa-type ${qa.type}">${qa.type}</span>
                        <p>${qa.question}</p>
                    </div>
                    <div class="qa-answer"><strong>Answer:</strong><p>${qa.answer}</p></div>
                </div>`;
        });
        out.innerHTML = html;
    } catch (e) {
        document.getElementById('qa-output').innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}

async function runQuiz() {
    if (!studyContentFile) { alert('Please upload a PDF first!'); return; }
    const num = document.getElementById('quiz-count').value;
    showStudyLoading('quiz-output', 'Generating quiz questions...');
    try {
        const res = await fetch('/study/quiz', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: studyContentFile, num_questions: parseInt(num) })
        });
        const data = await res.json();
        const out = document.getElementById('quiz-output');
        if (!data.success || !data.questions.length) {
            let errMsg = 'Could not generate quiz.';
            if (data.raw) errMsg += `<br><small style="color:rgba(255,255,255,0.4)">Raw: ${data.raw}</small>`;
            out.innerHTML = `<p style="color:#f87171">${errMsg}</p>`;
            return;
        }
        currentQuizData = data.questions;
        currentQuizIndex = 0;
        currentQuizScore = 0;
        showQuizQuestion(out);
    } catch (e) {
        document.getElementById('quiz-output').innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}

function showQuizQuestion(out) {
    if (currentQuizIndex >= currentQuizData.length) {
        const pct = Math.round((currentQuizScore / currentQuizData.length) * 100);
        out.innerHTML = `
            <div class="quiz-complete">
                <div class="quiz-score-circle">${pct}%</div>
                <h3>Quiz Complete!</h3>
                <p>Score: ${currentQuizScore}/${currentQuizData.length}</p>
                <p>${pct >= 80 ? '🎉 Excellent!' : pct >= 60 ? '👍 Good job!' : '📚 Keep studying!'}</p>
                <button class="study-run-btn" style="margin-top:1rem" onclick="runQuiz()">Retry</button>
            </div>`;
        return;
    }
    const q = currentQuizData[currentQuizIndex];
    out.innerHTML = `
        <div class="quiz-progress">Q${currentQuizIndex + 1}/${currentQuizData.length} · Score: ${currentQuizScore}</div>
        <div class="quiz-question">${q.question}</div>
        <div class="quiz-options">
            ${Object.entries(q.options).map(([key, val]) => `
                <button class="quiz-option" onclick="answerQuiz('${key}','${q.answer}',this)">
                    <span class="quiz-key">${key}</span>${val}
                </button>`).join('')}
        </div>
        <div id="quiz-feedback"></div>`;
}

function answerQuiz(selected, correct, btn) {
    document.querySelectorAll('.quiz-option').forEach(b => b.disabled = true);
    const feedback = document.getElementById('quiz-feedback');
    if (selected === correct) {
        btn.classList.add('correct-ans');
        feedback.innerHTML = '<p style="color:#34d399;margin-top:0.5rem">✅ Correct!</p>';
        currentQuizScore++;
    } else {
        btn.classList.add('wrong-ans');
        feedback.innerHTML = `<p style="color:#f87171;margin-top:0.5rem">❌ Wrong! Answer: ${correct}</p>`;
        document.querySelectorAll('.quiz-option').forEach(b => {
            if (b.querySelector('.quiz-key').textContent === correct) b.classList.add('correct-ans');
        });
    }
    setTimeout(() => { currentQuizIndex++; showQuizQuestion(document.getElementById('quiz-output')); }, 1500);
}

async function runFlashcards() {
    if (!studyContentFile) { alert('Please upload a PDF first!'); return; }
    const num = document.getElementById('flash-count').value;
    showStudyLoading('flash-output', 'Creating flashcards...');
    try {
        const res = await fetch('/study/flashcards', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: studyContentFile, num_cards: parseInt(num) })
        });
        const data = await res.json();
        const out = document.getElementById('flash-output');
        if (!data.success || !data.cards.length) { out.innerHTML = '<p style="color:#f87171">Could not create flashcards.</p>'; return; }
        flashcards = data.cards;
        currentFlashIndex = 0;
        showFlashcard(out);
    } catch (e) {
        document.getElementById('flash-output').innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}

function showFlashcard(out) {
    if (!flashcards.length) return;
    const card = flashcards[currentFlashIndex];
    out.innerHTML = `
        <div class="flash-progress">${currentFlashIndex + 1} / ${flashcards.length}</div>
        <div class="flashcard" id="flashcard" onclick="flipCard()">
            <div class="flashcard-inner" id="flashcard-inner">
                <div class="flashcard-front">
                    <span class="flash-label">QUESTION</span>
                    <p>${card.front}</p>
                    <span class="flash-hint">Click to flip</span>
                </div>
                <div class="flashcard-back">
                    <span class="flash-label">ANSWER</span>
                    <p>${card.back}</p>
                </div>
            </div>
        </div>
        <div class="flash-nav">
            <button class="study-run-btn" onclick="prevCard()" ${currentFlashIndex===0?'disabled':''}>← Prev</button>
            <button class="study-run-btn" onclick="nextCard()" ${currentFlashIndex===flashcards.length-1?'disabled':''}>Next →</button>
        </div>`;
}

function flipCard() { document.getElementById('flashcard-inner').classList.toggle('flipped'); }
function nextCard() { if (currentFlashIndex < flashcards.length - 1) { currentFlashIndex++; showFlashcard(document.getElementById('flash-output')); } }
function prevCard() { if (currentFlashIndex > 0) { currentFlashIndex--; showFlashcard(document.getElementById('flash-output')); } }

async function runNotes() {
    if (!studyContentFile) { alert('Please upload a PDF first!'); return; }
    const topic = document.getElementById('notes-topic').value;
    showStudyLoading('notes-output', 'Generating smart notes...');
    try {
        const res = await fetch('/study/notes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: studyContentFile, topic })
        });
        const data = await res.json();
        document.getElementById('notes-output').innerHTML =
            `<div class="notes-content">${formatText(data.notes)}</div>`;
    } catch (e) {
        document.getElementById('notes-output').innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}

async function runMath() {
    const problem = document.getElementById('math-input').value.trim();
    if (!problem) { alert('Please enter a problem!'); return; }
    showStudyLoading('math-output', 'Solving...');
    try {
        const res = await fetch('/study/math', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ problem })
        });
        const data = await res.json();
        document.getElementById('math-output').innerHTML =
            `<div class="notes-content">${formatText(data.solution)}</div>`;
    } catch (e) {
        document.getElementById('math-output').innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}

async function runCitation() {
    const info = document.getElementById('cite-input').value.trim();
    const style = document.getElementById('cite-style').value;
    if (!info) { alert('Please enter citation info!'); return; }
    showStudyLoading('cite-output', 'Generating...');
    try {
        const res = await fetch('/study/citation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ info, style })
        });
        const data = await res.json();
        document.getElementById('cite-output').innerHTML = `
            <div class="citation-box">
                <div class="citation-style">${style} Format</div>
                <p class="citation-text">${data.citation}</p>
                <button class="study-run-btn" onclick="navigator.clipboard.writeText(\`${data.citation}\`)">📋 Copy</button>
            </div>`;
    } catch (e) {
        document.getElementById('cite-output').innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}

async function runCode(action) {
    let payload = { action };
    if (action === 'explain') {
        payload.code = document.getElementById('code-input').value;
        payload.question = document.getElementById('code-question').value;
    } else if (action === 'fix') {
        payload.code = document.getElementById('fix-input').value;
        payload.error = document.getElementById('fix-error').value;
    } else {
        payload.question = document.getElementById('gen-input').value;
        payload.language = document.getElementById('gen-language').value;
    }
    if (!payload.code && !payload.question) {
        alert('Please enter code or description!'); return;
    }

    const out = document.getElementById('code-output');
    out.innerHTML = `
        <div class="notes-content" id="code-stream">
            <span class="cursor">▋</span>
        </div>`;

    let fullText = '';

    try {
        const res = await fetch('/study/code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop();

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.token) {
                            fullText += data.token;
                            const stream = document.getElementById('code-stream');
                            if (stream) {
                                stream.innerHTML = formatText(fullText)
                                    .replace(/```(\w+)?\n?([\s\S]*?)```/g,
                                        '<pre class="code-block"><code>$2</code></pre>')
                                    + '<span class="cursor">▋</span>';
                            }
                        }
                        if (data.done) {
                            const stream = document.getElementById('code-stream');
                            if (stream) {
                                stream.innerHTML = formatText(fullText)
                                    .replace(/```(\w+)?\n?([\s\S]*?)```/g,
                                        '<pre class="code-block"><code>$2</code></pre>');
                            }
                        }
                        if (data.error) {
                            out.innerHTML = `<p style="color:#f87171">Error: ${data.error}</p>`;
                        }
                    } catch {}
                }
            }
        }
    } catch (e) {
        out.innerHTML = `<p style="color:#f87171">Error: ${e.message}</p>`;
    }
}
// ══════════════════════════════════════
// ── SETTINGS ──
// ══════════════════════════════════════

function openSettings() {
    document.getElementById('settings-overlay').style.display = 'flex';
    updateSettingsUI();
}

function closeSettings() {
    document.getElementById('settings-overlay').style.display = 'none';
}

function updateSettingsUI() {
    document.querySelectorAll('.theme-card').forEach(c => {
        c.classList.toggle('active', c.dataset.theme === currentTheme);
    });
    document.querySelectorAll('.lang-card').forEach(c => {
        c.classList.toggle('active', c.dataset.lang === currentLanguage);
    });
}

function switchSettingsTab(tab) {
    document.querySelectorAll('.stab').forEach((b, i) => {
        const tabs = ['profile', 'theme', 'language'];
        b.classList.toggle('active', tabs[i] === tab);
    });
    document.querySelectorAll('.stab-content').forEach(c => c.classList.remove('active'));
    document.getElementById(`stab-${tab}`).classList.add('active');
}

function selectTheme(theme) {
    currentTheme = theme;
    applyTheme(theme);
    updateSettingsUI();
    saveSettingsQuick();
}

function selectLanguage(lang) {
    currentLanguage = lang;
    applyTranslations();
    updateSettingsUI();
    saveSettingsQuick();
}

async function saveSettingsQuick() {
    try {
        await fetch('/api/profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ theme: currentTheme, language: currentLanguage })
        });
    } catch (e) { console.error(e); }
}

async function saveProfile() {
    const username = document.getElementById('settings-username').value.trim();
    const currentPass = document.getElementById('settings-current-pass').value;
    const newPass = document.getElementById('settings-new-pass').value;
    const msgEl = document.getElementById('profile-msg');
    msgEl.style.color = 'rgba(255,255,255,0.5)';
    msgEl.textContent = 'Saving...';
    try {
        const res = await fetch('/api/profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username, current_password: currentPass,
                new_password: newPass, theme: currentTheme, language: currentLanguage
            })
        });
        const data = await res.json();
        if (data.success) {
            msgEl.style.color = '#34d399';
            msgEl.textContent = '✅ Saved!';
            document.querySelector('.user-name').textContent = data.username;
            setTimeout(() => msgEl.textContent = '', 3000);
        } else {
            msgEl.style.color = '#f87171';
            msgEl.textContent = '❌ ' + data.error;
        }
    } catch (e) {
        msgEl.style.color = '#f87171';
        msgEl.textContent = '❌ Error saving';
    }
}

async function uploadProfilePic() {
    const file = document.getElementById('pic-input').files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('picture', file);
    try {
        const res = await fetch('/api/profile/picture', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            const preview = document.getElementById('profile-pic-preview');
            preview.src = data.profile_pic + '?t=' + Date.now();
            preview.style.display = 'block';
            document.getElementById('pic-placeholder').style.display = 'none';
            const wrap = document.querySelector('.user-avatar-wrap');
            if (wrap) wrap.innerHTML = `<img src="${data.profile_pic}?t=${Date.now()}" class="user-avatar-img" alt="profile">`;
        }
    } catch (e) { console.error(e); }
}

// ── HTML Preview ──
function showHtmlPreview(htmlFile, appName) {
    const panel = document.getElementById('terminal-panel');
    const titleEl = document.getElementById('terminal-title');
    const output = document.getElementById('terminal-output');
    panel.style.display = 'flex';
    titleEl.textContent = appName;
    output.innerHTML = '';

    fetch('/preview-app', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ html_file: htmlFile })
    }).then(r => r.json()).then(data => {
        if (data.html) {
            // Add toolbar with open in window button
            const toolbar = document.createElement('div');
            toolbar.style.cssText = `
                display:flex;align-items:center;justify-content:space-between;
                padding:0.5rem 0.75rem;background:rgba(102,126,234,0.1);
                border-radius:8px 8px 0 0;border:1px solid rgba(102,126,234,0.2);
                margin-bottom:-1px;
            `;
            toolbar.innerHTML = `
                <span style="font-size:0.8rem;color:rgba(255,255,255,0.6);font-weight:600">${appName}</span>
                <div style="display:flex;gap:0.5rem">
                    <button onclick="openAppInNewWindow()" style="padding:0.3rem 0.75rem;background:var(--btn-gradient);border:none;border-radius:6px;color:white;font-size:0.75rem;cursor:pointer;font-family:'DM Sans',sans-serif">
                        🚀 Open in New Window
                    </button>
                    <button onclick="openAppFullscreen()" style="padding:0.3rem 0.75rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:6px;color:white;font-size:0.75rem;cursor:pointer;font-family:'DM Sans',sans-serif">
                        ⛶ Fullscreen
                    </button>
                </div>`;
            output.appendChild(toolbar);

            // Create resizable iframe
            const iframeWrap = document.createElement('div');
            iframeWrap.id = 'iframe-wrap';
            iframeWrap.style.cssText = `
                position:relative;
                width:100%;
                height:400px;
                min-height:200px;
                max-height:700px;
                overflow:hidden;
                border-radius:0 0 8px 8px;
                border:1px solid rgba(255,255,255,0.08);
            `;

            const iframe = document.createElement('iframe');
            iframe.id = 'app-preview-iframe';
            iframe.style.cssText = 'width:100%;height:100%;border:none;';
            iframeWrap.appendChild(iframe);

            // Drag handle at bottom
            const dragHandle = document.createElement('div');
            dragHandle.id = 'iframe-drag-handle';
            dragHandle.style.cssText = `
                position:absolute;
                bottom:0;left:0;right:0;
                height:8px;
                background:linear-gradient(transparent, rgba(102,126,234,0.3));
                cursor:ns-resize;
                display:flex;
                align-items:center;
                justify-content:center;
            `;
            dragHandle.innerHTML = '<div style="width:40px;height:3px;background:rgba(255,255,255,0.2);border-radius:2px"></div>';
            iframeWrap.appendChild(dragHandle);

            output.appendChild(iframeWrap);

            // Write HTML to iframe
            iframe.contentDocument.open();
            iframe.contentDocument.write(data.html);
            iframe.contentDocument.close();

            // Store HTML for new window
            window._lastAppHtml = data.html;
            window._lastAppName = appName;

            // Init drag resize
            initIframeDragResize(dragHandle, iframeWrap);
        }
    });
}

function initIframeDragResize(handle, wrap) {
    let isDragging = false;
    let startY = 0;
    let startHeight = 0;

    handle.addEventListener('mousedown', (e) => {
        isDragging = true;
        startY = e.clientY;
        startHeight = wrap.offsetHeight;
        document.body.style.cursor = 'ns-resize';
        document.body.style.userSelect = 'none';
        // Disable iframe pointer events during drag
        const iframe = document.getElementById('app-preview-iframe');
        if (iframe) iframe.style.pointerEvents = 'none';
        e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const diff = e.clientY - startY;
        const newHeight = Math.min(Math.max(startHeight + diff, 150), 700);
        wrap.style.height = newHeight + 'px';
    });

    document.addEventListener('mouseup', () => {
        if (isDragging) {
            isDragging = false;
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            const iframe = document.getElementById('app-preview-iframe');
            if (iframe) iframe.style.pointerEvents = '';
        }
    });
}

function openAppInNewWindow() {
    if (!window._lastAppHtml) { alert('No app loaded!'); return; }
    const newWin = window.open('', '_blank',
        'width=1000,height=700,toolbar=no,menubar=no,scrollbars=yes,resizable=yes');
    newWin.document.open();
    newWin.document.write(window._lastAppHtml);
    newWin.document.close();
    newWin.document.title = window._lastAppName || 'App';
}

function openAppFullscreen() {
    const iframe = document.getElementById('app-preview-iframe');
    if (!iframe) { alert('No app loaded!'); return; }
    if (iframe.requestFullscreen) {
        iframe.requestFullscreen();
    } else if (iframe.webkitRequestFullscreen) {
        iframe.webkitRequestFullscreen();
    }
}

// ── Terminal ──
function closeTerminal() { stopApp(); document.getElementById('terminal-panel').style.display = 'none'; }
function appendTerminal(text) {
    const output = document.getElementById('terminal-output');
    const span = document.createElement('span');
    span.textContent = text;
    span.style.color = text.includes('Error') ? '#f87171' : '#e8e8f0';
    output.appendChild(span);
    output.scrollTop = output.scrollHeight;
}
function stopApp() { socket.emit('kill_app', { session_id: sessionId }); }

async function exportExe() {
    if (!currentProjectDir) { alert('No app to export!'); return; }
    const btn = document.querySelector('.export-btn');
    btn.textContent = 'Building...';
    try {
        const res = await fetch('/export-exe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ project_dir: currentProjectDir, app_name: currentAppName })
        });
        const data = await res.json();
        if (data.success) addFormattedMessage('assistant', `**Executable created!**\n\nPath: ${data.exe_path}`, 'agent');
        else addMessage('assistant', 'Export failed: ' + data.error);
    } catch (e) { addMessage('assistant', 'Export failed: ' + e.message); }
    finally { btn.textContent = 'Export .exe'; }
}

document.addEventListener('DOMContentLoaded', () => {
    const termInput = document.getElementById('terminal-input');
    if (termInput) {
        termInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const value = termInput.value;
                appendTerminal(value + '\r\n');
                socket.emit('terminal_input', { session_id: sessionId, data: value + '\n' });
                termInput.value = '';
            }
        });
    }
});

// ── Image Upload ──
document.getElementById("image-input").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    selectedImage = file;
    document.getElementById("preview-img").src = URL.createObjectURL(file);
    document.getElementById("image-preview").style.display = "inline-flex";
});

function removeImage() {
    selectedImage = null;
    document.getElementById("image-preview").style.display = "none";
    document.getElementById("image-input").value = "";
}

// ── PDF/Ebook ──
document.getElementById("pdf-input").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const status = document.getElementById("pdf-status");
    status.textContent = "Processing...";
    const fd = new FormData();
    fd.append("file", file);
    try {
        const res = await fetch("/upload-pdf", { method: "POST", body: fd });
        const data = await res.json();
        status.textContent = data.success ? "✅ PDF Ready" : "❌ Failed";
    } catch { status.textContent = "❌ Error"; }
});

document.getElementById("ebook-input").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const status = document.getElementById("ebook-status");
    status.textContent = "Processing...";
    const fd = new FormData();
    fd.append("file", file);
    try {
        const res = await fetch("/upload-ebook", { method: "POST", body: fd });
        const data = await res.json();
        status.textContent = data.success ? "✅ Ready" : "❌ Failed";
    } catch { status.textContent = "❌ Error"; }
});

// ── Voice ──
document.getElementById("voice-btn").addEventListener("click", async () => {
    const btn = document.getElementById("voice-btn");
    const status = document.getElementById("voice-status");
    if (!isRecording) {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = [];
            mediaRecorder.ondataavailable = (e) => audioChunks.push(e.data);
            mediaRecorder.start();
            isRecording = true;
            btn.classList.add("recording");
            status.textContent = "Stop";
        } catch { alert("Microphone access denied!"); }
    } else {
        mediaRecorder.stop();
        isRecording = false;
        btn.classList.remove("recording");
        status.textContent = "Processing...";
        mediaRecorder.onstop = async () => {
            const blob = new Blob(audioChunks, { type: "audio/wav" });
            const fd = new FormData();
            fd.append("audio", blob, "voice.wav");
            try {
                const res = await fetch("/voice", { method: "POST", body: fd });
                const data = await res.json();
                if (data.answer) addMessage("assistant", data.answer);
            } catch { addMessage("assistant", "Voice failed"); }
            finally { status.textContent = t('voiceInput'); }
        };
    }
});

// ── Buttons ──
document.getElementById("agent-btn").addEventListener("click", activateAgent);
document.getElementById("image-btn").addEventListener("click", activateImageMode);

document.getElementById("message-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
});

async function logout() {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login';
}

// ── Resizable Right Sidebar ──
function initResizableSidebar() {
    const rightSidebar = document.getElementById('right-sidebar');
    if (!rightSidebar) return;

    // Set default wider width
    rightSidebar.style.width = '320px';

    // Create resize handle
    const handle = document.createElement('div');
    handle.id = 'rs-resize-handle';
    handle.style.cssText = `
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 6px;
        cursor: col-resize;
        background: transparent;
        z-index: 100;
        transition: background 0.2s;
    `;
    handle.title = "Drag to resize";
    rightSidebar.insertBefore(handle, rightSidebar.firstChild);

    handle.addEventListener('mouseenter', () => {
        handle.style.background = 'rgba(102,126,234,0.5)';
    });
    handle.addEventListener('mouseleave', () => {
        if (!isResizing) handle.style.background = 'transparent';
    });

    let isResizing = false;
    let startX = 0;
    let startWidth = 0;

    handle.addEventListener('mousedown', (e) => {
        isResizing = true;
        startX = e.clientX;
        startWidth = rightSidebar.offsetWidth;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        handle.style.background = 'rgba(102,126,234,0.8)';
        e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;
        const diff = startX - e.clientX;
        const newWidth = Math.min(Math.max(startWidth + diff, 250), 700);
        rightSidebar.style.width = newWidth + 'px';
    });

    document.addEventListener('mouseup', () => {
        if (isResizing) {
            isResizing = false;
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            handle.style.background = 'transparent';
        }
    });

    // Double click to toggle between narrow and wide
    handle.addEventListener('dblclick', () => {
        const currentWidth = rightSidebar.offsetWidth;
        if (currentWidth < 400) {
            rightSidebar.style.width = '500px';
        } else {
            rightSidebar.style.width = '320px';
        }
    });
}