import requests
import os
import subprocess
import re
import json
import webbrowser

OLLAMA_URL = "http://localhost:11434"
TEXT_MODEL = "gemma3:4b"
PROJECTS_DIR = os.path.expanduser("~/RAG-NEW/projects")
os.makedirs(PROJECTS_DIR, exist_ok=True)


def ask_model(system, user, max_tokens=2000):
    try:
        full_response = ""
        res = requests.post(f"{OLLAMA_URL}/api/chat", json={
            "model": TEXT_MODEL,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user}
            ],
            "stream": True,
            "keep_alive": -1,
            "options": {
                "temperature": 0.1,
                "num_predict": max_tokens,
                "num_ctx": 2048
            }
        }, timeout=300, stream=True)
        for line in res.iter_lines():
            if line:
                try:
                    chunk = json.loads(line.decode('utf-8'))
                    token = chunk.get(
                        "message", {}).get("content", "")
                    if token:
                        full_response += token
                    if chunk.get("done"):
                        break
                except:
                    continue
        return full_response
    except Exception as e:
        return f"Error: {e}"


def extract_html(response):
    html_match = re.search(
        r'```html\n(.*?)```', response, re.DOTALL)
    if html_match:
        content = html_match.group(1).strip()
        if '<!DOCTYPE html>' in content or '<html' in content:
            return content
    if '<!DOCTYPE html>' in response:
        start = response.find('<!DOCTYPE html>')
        return response[start:].strip()
    if '<html' in response:
        start = response.find('<html')
        return response[start:].strip()
    return None


def launch_app(html_file, app_name):
    try:
        brave_paths = [
            "/usr/bin/brave-browser",
            "/usr/bin/brave",
            "/snap/bin/brave",
        ]
        chrome_paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
        ]
        for brave in brave_paths:
            if os.path.exists(brave):
                subprocess.Popen([
                    brave,
                    f"--app=file://{html_file}",
                    "--window-size=1100,750",
                    "--no-first-run",
                    "--disable-extensions"
                ])
                print("Opened in Brave app mode!")
                return "brave"
        for chrome in chrome_paths:
            if os.path.exists(chrome):
                subprocess.Popen([
                    chrome,
                    f"--app=file://{html_file}",
                    "--window-size=1100,750",
                    "--no-first-run"
                ])
                return "chrome"
        subprocess.Popen(
            ["xdg-open", html_file],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return "browser"
    except Exception as e:
        print(f"Launch error: {e}")
        webbrowser.open(f"file://{html_file}")
        return "browser"


def create_desktop_entry(project_dir, app_name, html_file):
    desktop_dir = os.path.expanduser("~/Desktop")
    os.makedirs(desktop_dir, exist_ok=True)
    desktop_file = os.path.join(
        desktop_dir, f"{app_name}.desktop")
    brave_paths = [
        "/usr/bin/brave-browser",
        "/usr/bin/brave",
        "/snap/bin/brave",
    ]
    browser = "xdg-open"
    for b in brave_paths:
        if os.path.exists(b):
            browser = b
            break
    if browser != "xdg-open":
        exec_cmd = (
            f'{browser} --app=file://{html_file}'
            f' --window-size=1100,750'
        )
    else:
        exec_cmd = f'xdg-open "{html_file}"'
    with open(desktop_file, "w") as f:
        f.write(f"""[Desktop Entry]
Version=1.0
Type=Application
Name={app_name.replace('_', ' ').title()}
Comment=Created by JANS-HUB AI Agent
Exec={exec_cmd}
Icon=text-html
Terminal=false
Categories=Application;
""")
    os.chmod(desktop_file, 0o755)
    try:
        subprocess.run(
            ["gio", "set", desktop_file,
             "metadata::trusted", "true"],
            capture_output=True
        )
    except:
        pass
    return desktop_file


def write_html_app(request):
    system = """You are a web developer. Output ONLY HTML code. Nothing else.
No explanation. No markdown. Just pure HTML starting with <!DOCTYPE html>."""

    user = f"""Write a complete single HTML file for: {request}

Rules:
- Start with <!DOCTYPE html>
- Dark purple gradient background (#0f0c29 to #302b63)
- Beautiful glassmorphism UI
- Fully working JavaScript
- All buttons must work
- Keep under 120 lines
- Output ONLY the HTML right now:"""

    response = ask_model(system, user, 2000)
    return response


def generate_fallback(request):
    req = request.lower()

    if any(w in req for w in ['calculator', 'calc']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Calculator</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif}
.calc{background:rgba(255,255,255,0.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:1.5rem;width:320px;box-shadow:0 25px 50px rgba(0,0,0,0.5)}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:1rem;font-size:1.4rem}
.display{background:rgba(0,0,0,0.4);border-radius:14px;padding:1rem;text-align:right;margin-bottom:1rem;border:1px solid rgba(255,255,255,0.1)}
.display .expr{color:rgba(255,255,255,0.4);font-size:0.85rem;min-height:20px}
.display .val{color:white;font-size:2.2rem;font-weight:300;word-break:break-all}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:0.6rem}
button{padding:1.1rem;border:none;border-radius:12px;font-size:1.1rem;font-weight:600;cursor:pointer;transition:all 0.15s;color:white}
button:hover{transform:scale(1.05)}
button:active{transform:scale(0.95)}
.num{background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.08)}
.num:hover{background:rgba(255,255,255,0.18)}
.op{background:linear-gradient(135deg,#667eea,#764ba2)}
.eq{background:linear-gradient(135deg,#f093fb,#f5576c);grid-column:span 2}
.clear{background:rgba(239,68,68,0.3);border:1px solid rgba(239,68,68,0.3);color:#fca5a5}
.zero{grid-column:span 2}
</style>
</head>
<body>
<div class="calc">
<h1>Calculator</h1>
<div class="display">
<div class="expr" id="expr"></div>
<div class="val" id="val">0</div>
</div>
<div class="grid">
<button class="clear" onclick="clearAll()">AC</button>
<button class="num" onclick="toggleSign()">+/-</button>
<button class="num" onclick="percent()">%</button>
<button class="op" onclick="setOp('/')">÷</button>
<button class="num" onclick="inp('7')">7</button>
<button class="num" onclick="inp('8')">8</button>
<button class="num" onclick="inp('9')">9</button>
<button class="op" onclick="setOp('*')">×</button>
<button class="num" onclick="inp('4')">4</button>
<button class="num" onclick="inp('5')">5</button>
<button class="num" onclick="inp('6')">6</button>
<button class="op" onclick="setOp('-')">−</button>
<button class="num" onclick="inp('1')">1</button>
<button class="num" onclick="inp('2')">2</button>
<button class="num" onclick="inp('3')">3</button>
<button class="op" onclick="setOp('+')">+</button>
<button class="num zero" onclick="inp('0')">0</button>
<button class="num" onclick="dot()">.</button>
<button class="eq" onclick="calc()">=</button>
</div>
</div>
<script>
let cur='0',prev='',op='',fresh=false;
const val=document.getElementById('val');
const expr=document.getElementById('expr');
function update(){val.textContent=cur}
function inp(n){if(fresh){cur=n;fresh=false}else cur=cur==='0'?n:cur+n;update()}
function dot(){if(fresh){cur='0.';fresh=false}else if(!cur.includes('.'))cur+='.';update()}
function setOp(o){prev=cur;op=o;fresh=true;expr.textContent=prev+' '+o;}
function calc(){
if(!op||!prev)return;
let a=parseFloat(prev),b=parseFloat(cur),r=0;
if(op==='/')r=b?a/b:'Error';
else if(op==='*')r=a*b;
else if(op==='+')r=a+b;
else if(op==='-')r=a-b;
expr.textContent=prev+' '+op+' '+cur+' =';
cur=String(parseFloat(r.toFixed(10)));
op='';prev='';fresh=true;update()}
function clearAll(){cur='0';prev='';op='';fresh=false;expr.textContent='';update()}
function toggleSign(){cur=String(-parseFloat(cur));update()}
function percent(){cur=String(parseFloat(cur)/100);update()}
document.addEventListener('keydown',e=>{
if('0123456789'.includes(e.key))inp(e.key);
else if(e.key==='+')setOp('+');
else if(e.key==='-')setOp('-');
else if(e.key==='*')setOp('*');
else if(e.key==='/')setOp('/');
else if(e.key==='Enter'||e.key==='=')calc();
else if(e.key==='Backspace'){cur=cur.length>1?cur.slice(0,-1):'0';update()}
else if(e.key==='Escape')clearAll();
else if(e.key==='.')dot();});
</script>
</body>
</html>'''

    elif any(w in req for w in ['bmi', 'body mass']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>BMI Calculator</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif;color:white;padding:1rem}
.app{background:rgba(255,255,255,0.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:2rem;width:400px;box-shadow:0 25px 50px rgba(0,0,0,0.5)}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:1.5rem;font-size:1.8rem}
label{display:block;color:rgba(255,255,255,0.6);font-size:0.85rem;margin-bottom:0.4rem;margin-top:1rem}
input{width:100%;padding:0.875rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:12px;color:white;font-size:1rem;outline:none}
button{width:100%;padding:1rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:12px;color:white;font-size:1.1rem;font-weight:600;cursor:pointer;margin-top:1.5rem}
.result{margin-top:1.5rem;padding:1.5rem;background:rgba(255,255,255,0.05);border-radius:16px;text-align:center;display:none}
.bmi-val{font-size:3rem;font-weight:700;background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.bmi-cat{font-size:1.2rem;margin-top:0.5rem;color:rgba(255,255,255,0.7)}
</style>
</head>
<body>
<div class="app">
<h1>BMI Calculator</h1>
<label>Weight (kg)</label>
<input type="number" id="weight" placeholder="e.g. 70">
<label>Height (cm)</label>
<input type="number" id="height" placeholder="e.g. 175">
<button onclick="calcBMI()">Calculate BMI</button>
<div class="result" id="result">
<div class="bmi-val" id="bmiVal"></div>
<div class="bmi-cat" id="bmiCat"></div>
</div>
</div>
<script>
function calcBMI(){
const w=parseFloat(document.getElementById('weight').value);
const h=parseFloat(document.getElementById('height').value)/100;
if(!w||!h)return alert('Please enter both values');
const bmi=(w/(h*h)).toFixed(1);
let cat='',color='';
if(bmi<18.5){cat='Underweight';color='#60a5fa'}
else if(bmi<25){cat='Normal Weight';color='#34d399'}
else if(bmi<30){cat='Overweight';color='#fbbf24'}
else{cat='Obese';color='#f87171'}
document.getElementById('bmiVal').textContent=bmi;
document.getElementById('bmiCat').textContent=cat;
document.getElementById('bmiCat').style.color=color;
document.getElementById('result').style.display='block';}
</script>
</body>
</html>'''

    elif any(w in req for w in ['todo', 'task', 'to-do', 'to do']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Todo App</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif;color:white;padding:1rem}
.app{background:rgba(255,255,255,0.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:2rem;width:500px;box-shadow:0 25px 50px rgba(0,0,0,0.5)}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:1.5rem;font-size:1.8rem}
.row{display:flex;gap:0.75rem;margin-bottom:1.5rem}
input{flex:1;padding:0.875rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:12px;color:white;font-size:1rem;outline:none}
input::placeholder{color:rgba(255,255,255,0.3)}
button{padding:0.875rem 1.25rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:12px;color:white;font-weight:600;cursor:pointer}
.item{display:flex;align-items:center;gap:0.75rem;padding:0.875rem;background:rgba(255,255,255,0.05);border-radius:12px;margin-bottom:0.5rem;border:1px solid rgba(255,255,255,0.08)}
.item.done span{text-decoration:line-through;opacity:0.4}
.item span{flex:1;cursor:pointer}
.del{padding:0.3rem 0.75rem;background:linear-gradient(135deg,#f093fb,#f5576c);border:none;border-radius:8px;color:white;cursor:pointer;font-size:0.8rem}
</style>
</head>
<body>
<div class="app">
<h1>Todo List</h1>
<div class="row">
<input id="inp" placeholder="Add task..." onkeydown="if(event.key==='Enter')add()">
<button onclick="add()">Add</button>
</div>
<div id="list"></div>
</div>
<script>
let todos=JSON.parse(localStorage.getItem('todos')||'[]');
function save(){localStorage.setItem('todos',JSON.stringify(todos))}
function render(){
const l=document.getElementById('list');
l.innerHTML=todos.length?todos.map((t,i)=>`
<div class="item ${t.done?'done':''}">
<input type="checkbox" ${t.done?'checked':''} onchange="toggle(${i})">
<span onclick="toggle(${i})">${t.text}</span>
<button class="del" onclick="del(${i})">Delete</button>
</div>`).join(''):'<p style="text-align:center;opacity:0.4;color:white">No tasks yet!</p>'}
function add(){
const i=document.getElementById('inp');
if(!i.value.trim())return;
todos.push({text:i.value.trim(),done:false});
i.value='';save();render();}
function toggle(i){todos[i].done=!todos[i].done;save();render()}
function del(i){todos.splice(i,1);save();render()}
render();
</script>
</body>
</html>'''

    elif any(w in req for w in ['inventory', 'stock', 'warehouse']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Inventory Manager</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;font-family:"Segoe UI",sans-serif;color:white;padding:2rem}
.app{max-width:800px;margin:0 auto}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:2rem;font-size:2rem}
.form{background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:1.5rem;margin-bottom:1.5rem;display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:0.75rem;align-items:end}
label{display:block;color:rgba(255,255,255,0.5);font-size:0.8rem;margin-bottom:0.3rem}
input{width:100%;padding:0.75rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:10px;color:white;font-size:0.95rem;outline:none}
.add-btn{padding:0.75rem 1.5rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:10px;color:white;font-weight:600;cursor:pointer}
table{width:100%;border-collapse:collapse;background:rgba(255,255,255,0.05);border-radius:16px;overflow:hidden}
th{background:rgba(102,126,234,0.3);padding:1rem;text-align:left;font-size:0.85rem;color:rgba(255,255,255,0.7)}
td{padding:0.875rem 1rem;border-bottom:1px solid rgba(255,255,255,0.05)}
.del-btn{padding:0.3rem 0.75rem;background:linear-gradient(135deg,#f093fb,#f5576c);border:none;border-radius:7px;color:white;cursor:pointer;font-size:0.8rem}
.total{background:rgba(255,255,255,0.07);border-radius:12px;padding:1rem 1.5rem;margin-top:1rem;text-align:right;font-size:1.1rem;color:white}
</style>
</head>
<body>
<div class="app">
<h1>Inventory Manager</h1>
<div class="form">
<div><label>Product</label><input id="name" placeholder="Product name"></div>
<div><label>Quantity</label><input id="qty" type="number" placeholder="0"></div>
<div><label>Price ($)</label><input id="price" type="number" placeholder="0.00"></div>
<button class="add-btn" onclick="add()">Add</button>
</div>
<table>
<thead><tr><th>#</th><th>Product</th><th>Qty</th><th>Price</th><th>Total</th><th>Action</th></tr></thead>
<tbody id="tbody"></tbody>
</table>
<div class="total">Grand Total: <span id="grand" style="background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:700">$0.00</span></div>
</div>
<script>
let items=JSON.parse(localStorage.getItem('inv')||'[]');
function save(){localStorage.setItem('inv',JSON.stringify(items))}
function render(){
const tb=document.getElementById('tbody');
let grand=0;
tb.innerHTML=items.map((it,i)=>{
const tot=it.qty*it.price;grand+=tot;
return`<tr><td style="color:white">${i+1}</td><td style="color:white">${it.name}</td><td style="color:white">${it.qty}</td><td style="color:white">$${parseFloat(it.price).toFixed(2)}</td><td style="color:white">$${tot.toFixed(2)}</td><td><button class="del-btn" onclick="del(${i})">Delete</button></td></tr>`;
}).join('');
document.getElementById('grand').textContent='$'+grand.toFixed(2);}
function add(){
const name=document.getElementById('name').value.trim();
const qty=parseInt(document.getElementById('qty').value);
const price=parseFloat(document.getElementById('price').value);
if(!name||!qty||!price)return alert('Fill all fields!');
items.push({name,qty,price});
document.getElementById('name').value='';
document.getElementById('qty').value='';
document.getElementById('price').value='';
save();render();}
function del(i){items.splice(i,1);save();render()}
render();
</script>
</body>
</html>'''

    elif any(w in req for w in ['quiz', 'trivia']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Quiz App</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif;color:white;padding:1rem}
.app{background:rgba(255,255,255,0.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:2rem;width:550px}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:1.5rem;font-size:1.8rem}
.progress{background:rgba(255,255,255,0.1);border-radius:100px;height:6px;margin-bottom:1.5rem;overflow:hidden}
.bar{height:100%;background:linear-gradient(135deg,#667eea,#f093fb);border-radius:100px;transition:width 0.3s}
.question{font-size:1.1rem;margin-bottom:1.5rem;line-height:1.6}
.options{display:flex;flex-direction:column;gap:0.75rem;margin-bottom:1rem}
.option{padding:0.875rem 1rem;background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.12);border-radius:12px;cursor:pointer;text-align:left;color:white;font-size:1rem;transition:all 0.2s}
.option:hover{background:rgba(102,126,234,0.2)}
.correct{background:rgba(52,211,153,0.2)!important;border-color:#34d399!important}
.wrong{background:rgba(248,113,113,0.2)!important;border-color:#f87171!important}
.score{text-align:center;color:rgba(255,255,255,0.6);margin-bottom:1rem}
button.next{width:100%;padding:0.875rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:12px;color:white;font-weight:600;cursor:pointer;display:none}
</style>
</head>
<body>
<div class="app">
<h1>Quiz App</h1>
<div class="progress"><div class="bar" id="bar"></div></div>
<div class="score">Q <span id="qn">1</span>/5 | Score: <span id="sc">0</span></div>
<br>
<div class="question" id="q"></div>
<div class="options" id="opts"></div>
<button class="next" id="nb" onclick="next()">Next</button>
</div>
<script>
const qs=[
{q:"Capital of France?",opts:["London","Paris","Berlin","Rome"],a:1},
{q:"2 + 2 = ?",opts:["3","4","5","6"],a:1},
{q:"Closest planet to Sun?",opts:["Venus","Earth","Mercury","Mars"],a:2},
{q:"H2O is?",opts:["Oxygen","Carbon","Water","Hydrogen"],a:2},
{q:"How many continents?",opts:["5","6","7","8"],a:2}
];
let cur=0,sc=0,done=false;
function show(){
const q=qs[cur];
document.getElementById('q').textContent=q.q;
document.getElementById('qn').textContent=cur+1;
document.getElementById('bar').style.width=((cur/qs.length)*100)+'%';
document.getElementById('opts').innerHTML=q.opts.map((o,i)=>`<button class="option" onclick="ans(${i})">${o}</button>`).join('');
document.getElementById('nb').style.display='none';
done=false;}
function ans(i){
if(done)return;done=true;
const btns=document.querySelectorAll('.option');
btns[qs[cur].a].classList.add('correct');
if(i!==qs[cur].a)btns[i].classList.add('wrong');
else sc++;
document.getElementById('sc').textContent=sc;
document.getElementById('nb').style.display='block';}
function next(){
cur++;
if(cur>=qs.length){
document.querySelector('.app').innerHTML=`<h1>Done!</h1><div style="text-align:center;margin-top:2rem"><div style="font-size:4rem;font-weight:700;background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent">${sc}/${qs.length}</div><div style="margin-top:1rem;color:rgba(255,255,255,0.6)">${sc>=4?'Excellent!':sc>=3?'Good!':'Keep trying!'}</div><button onclick="location.reload()" style="margin-top:2rem;padding:0.875rem 2rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:12px;color:white;cursor:pointer;font-size:1rem">Again</button></div>`;}
else show();}
show();
</script>
</body>
</html>'''

    elif any(w in req for w in ['budget', 'expense', 'finance', 'money']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Budget Tracker</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;font-family:"Segoe UI",sans-serif;color:white;padding:2rem}
.app{max-width:700px;margin:0 auto}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:2rem;font-size:2rem}
.cards{display:grid;grid-template-columns:1fr 1fr 1fr;gap:1rem;margin-bottom:2rem}
.card{background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:16px;padding:1.25rem;text-align:center}
.card-label{color:rgba(255,255,255,0.5);font-size:0.8rem;margin-bottom:0.5rem}
.card-val{font-size:1.6rem;font-weight:700}
.form{background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:1.5rem;margin-bottom:1.5rem;display:grid;grid-template-columns:1fr 1fr auto auto;gap:0.75rem;align-items:end}
label{display:block;color:rgba(255,255,255,0.5);font-size:0.8rem;margin-bottom:0.3rem}
input,select{width:100%;padding:0.75rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:10px;color:white;font-size:0.9rem;outline:none}
select option{background:#302b63}
.add-btn{padding:0.75rem 1rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:10px;color:white;font-weight:600;cursor:pointer}
.item{display:flex;justify-content:space-between;align-items:center;padding:0.875rem 1rem;background:rgba(255,255,255,0.05);border-radius:12px;margin-bottom:0.5rem;border:1px solid rgba(255,255,255,0.08)}
.type{padding:0.2rem 0.5rem;border-radius:6px;font-size:0.75rem;font-weight:600}
.inc{background:rgba(52,211,153,0.2);color:#34d399}
.exp{background:rgba(248,113,113,0.2);color:#f87171}
.del-btn{padding:0.3rem 0.6rem;background:rgba(248,113,113,0.3);border:none;border-radius:7px;color:#f87171;cursor:pointer;font-size:0.8rem}
</style>
</head>
<body>
<div class="app">
<h1>Budget Tracker</h1>
<div class="cards">
<div class="card"><div class="card-label">Income</div><div class="card-val" style="color:#34d399" id="inc">$0</div></div>
<div class="card"><div class="card-label">Expenses</div><div class="card-val" style="color:#f87171" id="exp">$0</div></div>
<div class="card"><div class="card-label">Balance</div><div class="card-val" style="background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent" id="bal">$0</div></div>
</div>
<div class="form">
<div><label>Description</label><input id="desc" placeholder="e.g. Salary"></div>
<div><label>Amount</label><input id="amt" type="number" placeholder="0"></div>
<div><label>Type</label><select id="type"><option value="income">Income</option><option value="expense">Expense</option></select></div>
<button class="add-btn" onclick="add()">Add</button>
</div>
<div id="list"></div>
</div>
<script>
let txns=JSON.parse(localStorage.getItem('budget')||'[]');
function save(){localStorage.setItem('budget',JSON.stringify(txns))}
function render(){
let i=0,e=0;
txns.forEach(t=>{if(t.type==='income')i+=t.amount;else e+=t.amount;});
document.getElementById('inc').textContent='$'+i.toFixed(2);
document.getElementById('exp').textContent='$'+e.toFixed(2);
document.getElementById('bal').textContent='$'+(i-e).toFixed(2);
document.getElementById('list').innerHTML=txns.map((t,idx)=>`
<div class="item">
<span class="type ${t.type==='income'?'inc':'exp'}">${t.type}</span>
<span style="flex:1;margin:0 1rem;color:white">${t.desc}</span>
<span style="color:${t.type==='income'?'#34d399':'#f87171'};font-weight:600">$${t.amount.toFixed(2)}</span>
<button class="del-btn" onclick="del(${idx})">Del</button>
</div>`).join('')}
function add(){
const desc=document.getElementById('desc').value.trim();
const amount=parseFloat(document.getElementById('amt').value);
const type=document.getElementById('type').value;
if(!desc||!amount)return alert('Fill all fields!');
txns.push({desc,amount,type});
document.getElementById('desc').value='';
document.getElementById('amt').value='';
save();render();}
function del(i){txns.splice(i,1);save();render()}
render();
</script>
</body>
</html>'''

    elif any(w in req for w in ['password', 'pwd', 'generator']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Password Generator</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif;color:white;padding:1rem}
.app{background:rgba(255,255,255,0.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:2rem;width:450px}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:1.5rem;font-size:1.8rem}
.out{display:flex;gap:0.5rem;margin-bottom:1.5rem}
.pwd{flex:1;padding:0.875rem;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);border-radius:12px;color:#a78bfa;font-family:monospace;font-size:1rem;word-break:break-all}
.copy{padding:0.875rem 1rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:12px;color:white;cursor:pointer;font-weight:600}
label{display:flex;justify-content:space-between;color:rgba(255,255,255,0.7);font-size:0.9rem;margin-bottom:0.5rem;margin-top:1rem}
input[type=range]{width:100%;accent-color:#667eea}
.checks{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;margin:1rem 0}
.chk{display:flex;align-items:center;gap:0.5rem;color:rgba(255,255,255,0.7);font-size:0.9rem;cursor:pointer}
input[type=checkbox]{accent-color:#667eea;width:16px;height:16px}
.gen{width:100%;padding:1rem;background:linear-gradient(135deg,#f093fb,#f5576c);border:none;border-radius:12px;color:white;font-size:1.1rem;font-weight:600;cursor:pointer;margin-top:0.5rem}
</style>
</head>
<body>
<div class="app">
<h1>Password Generator</h1>
<div class="out">
<div class="pwd" id="pwd">Click Generate!</div>
<button class="copy" onclick="copy()">Copy</button>
</div>
<label>Length: <span id="lv">16</span></label>
<input type="range" id="len" min="4" max="64" value="16" oninput="document.getElementById('lv').textContent=this.value">
<div class="checks">
<label class="chk"><input type="checkbox" id="up" checked>Uppercase</label>
<label class="chk"><input type="checkbox" id="lo" checked>Lowercase</label>
<label class="chk"><input type="checkbox" id="nu" checked>Numbers</label>
<label class="chk"><input type="checkbox" id="sy" checked>Symbols</label>
</div>
<button class="gen" onclick="gen()">Generate</button>
</div>
<script>
function gen(){
let c='';
if(document.getElementById('up').checked)c+='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
if(document.getElementById('lo').checked)c+='abcdefghijklmnopqrstuvwxyz';
if(document.getElementById('nu').checked)c+='0123456789';
if(document.getElementById('sy').checked)c+='!@#$%^&*()_+-=[]{}|;:,.<>?';
if(!c){alert('Select at least one!');return;}
const l=parseInt(document.getElementById('len').value);
let p='';
for(let i=0;i<l;i++)p+=c[Math.floor(Math.random()*c.length)];
document.getElementById('pwd').textContent=p;}
function copy(){
navigator.clipboard.writeText(document.getElementById('pwd').textContent).then(()=>{
const b=document.querySelector('.copy');
b.textContent='Copied!';setTimeout(()=>b.textContent='Copy',2000);});}
gen();
</script>
</body>
</html>'''

    elif any(w in req for w in ['notes', 'note', 'notepad']):
        return '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Notes App</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;font-family:"Segoe UI",sans-serif;color:white;padding:2rem}
.app{max-width:700px;margin:0 auto}
h1{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:2rem;font-size:2rem}
.editor{background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:1.5rem;margin-bottom:1.5rem}
input.title{width:100%;padding:0.75rem;background:transparent;border:none;border-bottom:1px solid rgba(255,255,255,0.1);color:white;font-size:1.2rem;font-weight:600;outline:none;margin-bottom:1rem}
textarea{width:100%;background:transparent;border:none;color:rgba(255,255,255,0.8);font-size:1rem;outline:none;resize:none;min-height:120px;font-family:inherit;line-height:1.6}
.actions{display:flex;gap:0.75rem;margin-top:1rem}
button{padding:0.75rem 1.5rem;border:none;border-radius:10px;font-weight:600;cursor:pointer}
.save{background:linear-gradient(135deg,#667eea,#764ba2);color:white}
.clr{background:rgba(255,255,255,0.1);color:rgba(255,255,255,0.7)}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.note{background:rgba(255,255,255,0.07);border:1px solid rgba(255,255,255,0.1);border-radius:16px;padding:1.25rem;cursor:pointer;position:relative}
.note h3{font-size:1rem;margin-bottom:0.5rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.note p{font-size:0.85rem;color:rgba(255,255,255,0.5);overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical}
.dn{position:absolute;top:0.75rem;right:0.75rem;background:rgba(248,113,113,0.3);border:none;border-radius:6px;color:#f87171;cursor:pointer;padding:0.2rem 0.5rem;font-size:0.75rem}
.date{font-size:0.75rem;color:rgba(255,255,255,0.3);margin-top:0.5rem}
</style>
</head>
<body>
<div class="app">
<h1>Notes</h1>
<div class="editor">
<input class="title" id="nt" placeholder="Note title...">
<textarea id="nb" placeholder="Write your note..."></textarea>
<div class="actions">
<button class="save" onclick="save()">Save</button>
<button class="clr" onclick="clr()">Clear</button>
</div>
</div>
<div class="grid" id="grid"></div>
</div>
<script>
let notes=JSON.parse(localStorage.getItem('notes')||'[]');
let ei=-1;
function sl(){localStorage.setItem('notes',JSON.stringify(notes))}
function render(){
document.getElementById('grid').innerHTML=notes.map((n,i)=>`
<div class="note" onclick="edit(${i})">
<button class="dn" onclick="event.stopPropagation();del(${i})">Del</button>
<h3>${n.title||'Untitled'}</h3>
<p>${n.body}</p>
<div class="date">${n.date}</div>
</div>`).join('')}
function save(){
const t=document.getElementById('nt').value.trim();
const b=document.getElementById('nb').value.trim();
if(!b)return alert('Write something!');
const n={title:t||'Untitled',body:b,date:new Date().toLocaleDateString()};
if(ei>=0){notes[ei]=n;ei=-1;}else notes.unshift(n);
sl();render();clr();}
function clr(){document.getElementById('nt').value='';document.getElementById('nb').value='';ei=-1;}
function edit(i){document.getElementById('nt').value=notes[i].title;document.getElementById('nb').value=notes[i].body;ei=i;window.scrollTo(0,0);}
function del(i){notes.splice(i,1);sl();render()}
render();
</script>
</body>
</html>'''

    else:
        return None


def run_agent(user_request):
    steps = []
    app_name = re.sub(
        r'[^a-z0-9]', '_',
        user_request[:30].lower()
    ).strip('_')
    project_dir = os.path.join(PROJECTS_DIR, app_name)
    os.makedirs(project_dir, exist_ok=True)

    def log(msg):
        steps.append(msg)
        print(msg)

    log("Checking built-in templates...")
    html_content = generate_fallback(user_request)

    if html_content and '<!DOCTYPE html>' in html_content:
        log("Template found! Using optimized app...")
    else:
        log("Generating with AI (30-60 seconds)...")
        html_response = write_html_app(user_request)
        html_content = extract_html(html_response)

        if not html_content:
            log("Retrying with simpler prompt...")
            retry = ask_model(
                "Output ONLY complete HTML starting with <!DOCTYPE html>.",
                f"Create a simple working web app for: {user_request}",
                1500
            )
            html_content = extract_html(retry)

        if not html_content:
            log("Using generic template...")
            html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{user_request}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:linear-gradient(135deg,#0f0c29,#302b63);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif;color:white}}
.app{{background:rgba(255,255,255,0.07);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:2rem;width:500px;text-align:center}}
h1{{background:linear-gradient(135deg,#667eea,#f093fb);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:1.5rem;font-size:1.8rem}}
input{{width:100%;padding:0.875rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:12px;color:white;font-size:1rem;outline:none;margin-bottom:1rem}}
button{{width:100%;padding:0.875rem;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:12px;color:white;font-size:1rem;font-weight:600;cursor:pointer;margin-bottom:0.75rem}}
#out{{background:rgba(255,255,255,0.05);border-radius:12px;padding:1rem;min-height:60px;border:1px solid rgba(255,255,255,0.1)}}
</style>
</head>
<body>
<div class="app">
<h1>{user_request.title()}</h1>
<input type="text" id="inp" placeholder="Enter value...">
<button onclick="go()">Submit</button>
<div id="out">Result appears here...</div>
</div>
<script>
function go(){{
const v=document.getElementById('inp').value;
document.getElementById('out').textContent='You entered: '+v;
}}
</script>
</body>
</html>'''

    log("Saving files...")
    html_file = os.path.join(project_dir, "index.html")
    with open(html_file, "w", encoding="utf-8") as f:
        f.write(html_content)
    log("Created: index.html")

    log("Creating desktop shortcut...")
    create_desktop_entry(project_dir, app_name, html_file)
    log("Shortcut created!")

    log("Launching app...")
    launched = launch_app(html_file, app_name)
    log(f"App opened! ({launched})")

    status = "App created successfully!"

    return {
        "steps": steps,
        "code": html_content,
        "output": status,
        "status": status,
        "project_dir": project_dir,
        "html_file": html_file,
        "files": ["index.html"],
        "total_lines": len(html_content.split('\n')),
        "run_command": f"xdg-open {html_file}"
    }