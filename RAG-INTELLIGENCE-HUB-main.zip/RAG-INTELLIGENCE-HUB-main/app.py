from flask import Flask, request, jsonify, render_template, redirect, url_for, Response
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from database import db, User, Conversation
from rag import load_pdf, load_ebook, build_prompt, get_smart_chunks, get_doc_info
from image_gen import generate_image, is_image_request
from vision import process_image, unload_vision_model
from study_tools import (
    extract_pdf_text, generate_qa, generate_quiz,
    generate_flashcards, generate_smart_notes,
    solve_math, generate_citation,
    explain_code, fix_code, generate_code
)
import requests
import os
import base64
import gc
import time
import threading
import pty
import select
import subprocess
import json
import re
from datetime import datetime
from agent import run_agent

app = Flask(__name__)
app.config['SECRET_KEY'] = 'janshub_secret_2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jans_hub.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

CORS(app)
db.init_app(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login_page'

OLLAMA_URL = "http://localhost:11434"
UPLOAD_FOLDER = "uploads"
TEMP_FOLDER = "temp"
STUDY_FOLDER = "study_uploads"
PROFILE_FOLDER = "static/profiles"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMP_FOLDER, exist_ok=True)
os.makedirs(STUDY_FOLDER, exist_ok=True)
os.makedirs(PROFILE_FOLDER, exist_ok=True)

TEXT_MODEL = "gemma3-fast"

doc_chunks = []
active_processes = {}
active_masters = {}

JANS_PERSONALITY = """You are JANS, a witty, warm and highly intelligent AI assistant created by Jebin.
You have a friendly, slightly humorous personality and you genuinely care about helping users.
You refer to yourself as JANS.
You are smart, creative and always try your best to give helpful answers.
For simple questions: answer in 1-3 sentences.
For complex questions: be thorough but clear.
You never say you cannot help — you always try your best."""

LANGUAGE_PROMPTS = {
    'tamil': "Please respond in Tamil language (தமிழில் பதிலளிக்கவும்).",
    'hindi': "Please respond in Hindi language (हिंदी में जवाब दें).",
    'english': ""
}


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def get_language_prompt():
    if current_user.is_authenticated:
        lang = current_user.language or 'english'
        return LANGUAGE_PROMPTS.get(lang, "")
    return ""


def unload_model(model_name):
    try:
        requests.post(f"{OLLAMA_URL}/api/generate", json={
            "model": model_name,
            "keep_alive": 0
        }, timeout=10)
    except:
        pass


def handle_image_generation(message, conv, chat_history):
    patterns = [
        r'(?:generate|create|make|draw|paint|show|give)(?:\s+me)?\s+(?:a\s+)?(?:image|picture|photo|pic)\s+(?:of\s+)?(.+)',
        r'(?:image|picture|photo|pic)\s+of\s+(.+)',
        r'(?:draw|paint|illustrate)\s+(.+)',
    ]
    prompt = message
    for pattern in patterns:
        match = re.search(pattern, message.lower())
        if match:
            prompt = match.group(1).strip()
            break

    result = generate_image(prompt)
    if result['success']:
        img_path = os.path.join(
            UPLOAD_FOLDER, f"generated_{int(time.time())}.png")
        with open(img_path, 'wb') as f:
            f.write(base64.b64decode(result['image']))
        chat_history.append({"role": "user", "content": message})
        chat_history.append({
            "role": "assistant",
            "content": f"[Generated image of: {prompt}]"
        })
        conv.set_messages(chat_history)
        if conv.title == 'New Chat':
            conv.title = f"Image: {prompt[:40]}"
        conv.updated_at = datetime.utcnow()
        db.session.commit()
        return jsonify({
            "answer": f"Here is your image of: {prompt}",
            "mode": "image",
            "image": result['image'],
            "conv_id": conv.id,
            "conv_title": conv.title
        })
    else:
        return jsonify({
            "answer": f"Could not generate: {result['error']}",
            "mode": "text",
            "conv_id": conv.id,
            "conv_title": conv.title
        })


# ── Auth Routes ──
@app.route('/login', methods=['GET'])
def login_page():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('login.html')


@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({'error': 'Invalid email or password'}), 401
    login_user(user, remember=True)
    return jsonify({
        'success': True,
        'username': user.username,
        'theme': user.theme or 'purple',
        'language': user.language or 'english',
        'profile_pic': user.profile_pic or ''
    })


@app.route('/api/signup', methods=['POST'])
def api_signup():
    data = request.json
    username = data.get('username', '').strip()
    email = data.get('email', '').strip().lower()
    password = data.get('password', '')
    if not username or not email or not password:
        return jsonify({'error': 'All fields required'}), 400
    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already taken'}), 400
    user = User()
    user.username = username
    user.email = email
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    login_user(user, remember=True)
    return jsonify({'success': True, 'username': username})


@app.route('/api/logout', methods=['POST'])
@login_required
def api_logout():
    logout_user()
    return jsonify({'success': True})


# ── Profile Routes ──
@app.route('/api/profile', methods=['GET'])
@login_required
def get_profile():
    return jsonify({
        'username': current_user.username,
        'email': current_user.email,
        'profile_pic': current_user.profile_pic or '',
        'language': current_user.language or 'english',
        'theme': current_user.theme or 'purple'
    })


@app.route('/api/profile', methods=['POST'])
@login_required
def update_profile():
    data = request.json
    username = data.get('username', '').strip()
    language = data.get('language', 'english')
    theme = data.get('theme', 'purple')
    new_password = data.get('new_password', '')
    current_password = data.get('current_password', '')

    if username and username != current_user.username:
        if User.query.filter_by(username=username).first():
            return jsonify({'error': 'Username already taken'}), 400
        current_user.username = username

    if new_password:
        if not current_user.check_password(current_password):
            return jsonify({'error': 'Current password is wrong'}), 400
        current_user.set_password(new_password)

    current_user.language = language
    current_user.theme = theme
    db.session.commit()

    return jsonify({
        'success': True,
        'username': current_user.username,
        'theme': current_user.theme,
        'language': current_user.language
    })


@app.route('/api/profile/picture', methods=['POST'])
@login_required
def update_profile_picture():
    if 'picture' not in request.files:
        return jsonify({'error': 'No picture'}), 400
    file = request.files['picture']
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
        return jsonify({'error': 'Invalid file type'}), 400
    filename = f"profile_{current_user.id}{ext}"
    filepath = os.path.join(PROFILE_FOLDER, filename)
    file.save(filepath)
    pic_url = f"/static/profiles/{filename}"
    current_user.profile_pic = pic_url
    db.session.commit()
    return jsonify({'success': True, 'profile_pic': pic_url})


# ── Conversation Routes ──
@app.route('/api/conversations', methods=['GET'])
@login_required
def get_conversations():
    convs = Conversation.query.filter_by(
        user_id=current_user.id
    ).order_by(Conversation.updated_at.desc()).all()
    return jsonify([{
        'id': c.id,
        'title': c.title,
        'created_at': c.created_at.strftime('%Y-%m-%d %H:%M')
    } for c in convs])


@app.route('/api/conversations', methods=['POST'])
@login_required
def create_conversation():
    conv = Conversation()
    conv.user_id = current_user.id
    conv.title = 'New Chat'
    conv.set_messages([{
        "role": "system",
        "content": JANS_PERSONALITY
    }])
    db.session.add(conv)
    db.session.commit()
    return jsonify({'id': conv.id, 'title': conv.title})


@app.route('/api/conversations/<int:conv_id>', methods=['GET'])
@login_required
def get_conversation(conv_id):
    conv = Conversation.query.filter_by(
        id=conv_id, user_id=current_user.id).first()
    if not conv:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(conv.to_dict())


@app.route('/api/conversations/<int:conv_id>', methods=['DELETE'])
@login_required
def delete_conversation(conv_id):
    conv = Conversation.query.filter_by(
        id=conv_id, user_id=current_user.id).first()
    if not conv:
        return jsonify({'error': 'Not found'}), 404
    db.session.delete(conv)
    db.session.commit()
    return jsonify({'success': True})


# ── Main Routes ──
@app.route('/')
@login_required
def index():
    return render_template(
        'index.html',
        username=current_user.username,
        theme=current_user.theme or 'purple',
        language=current_user.language or 'english',
        profile_pic=current_user.profile_pic or ''
    )


@app.route('/status')
def status():
    try:
        res = requests.get(f"{OLLAMA_URL}/api/tags", timeout=3)
        return jsonify({"ready": res.ok})
    except:
        return jsonify({"ready": False})


@app.route('/chat', methods=['POST'])
@login_required
def chat():
    global doc_chunks

    message = request.form.get('message', '')
    image = request.files.get('image')
    conv_id = request.form.get('conv_id')

    conv = None
    if conv_id:
        conv = Conversation.query.filter_by(
            id=conv_id, user_id=current_user.id).first()
    if not conv:
        conv = Conversation()
        conv.user_id = current_user.id
        conv.title = 'New Chat'
        conv.set_messages([{
            "role": "system",
            "content": JANS_PERSONALITY
        }])
        db.session.add(conv)
        db.session.commit()

    chat_history = conv.get_messages()
    lang_prompt = get_language_prompt()

    # ── Vision Mode ──
# ── Vision Mode ──
# ── Vision Mode ──
    if image:
        # Save image first
        image_path = os.path.join(UPLOAD_FOLDER, image.filename)
        image.save(image_path)

        conv_id_val = conv.id
        conv_title_val = conv.title
        display_msg = f"[Image] {message or 'Describe this image'}"

        def stream_vision():
            from vision import (free_ram_for_vision, resize_image,
                               image_to_base64, build_vision_prompt,
                               unload_vision_model, VISION_MODEL)
            import json as _json

            # Free RAM
            free_ram_for_vision()

            # Resize image
            resize_image(image_path, max_size=(336, 336), quality=75)

            # Convert to base64
            img_b64 = image_to_base64(image_path)

            # Build prompt
            prompt = build_vision_prompt(message, lang_prompt)

            body = {
                "model": VISION_MODEL,
                "prompt": prompt,
                "images": [img_b64],
                "stream": True,
                "options": {
                    "num_predict": 800,
                    "num_ctx": 2048,
                    "temperature": 0.1
                }
            }

            answer = ""
            try:
                res = requests.post(
                    f"{OLLAMA_URL}/api/generate",
                    json=body,
                    stream=True,
                    timeout=300
                )

                for line in res.iter_lines():
                    if line:
                        try:
                            chunk = _json.loads(line.decode('utf-8'))
                            token = chunk.get("response", "")
                            if token:
                                answer += token
                                yield f"data: {_json.dumps({'token': token, 'mode': 'vision'})}\n\n"
                            if chunk.get("done"):
                                break
                        except:
                            continue

                unload_vision_model()

                # Save to database
                with app.app_context():
                    c = Conversation.query.get(conv_id_val)
                    if c:
                        history = c.get_messages()
                        history.append({"role": "user", "content": display_msg})
                        history.append({"role": "assistant", "content": answer})
                        c.set_messages(history)
                        if c.title == 'New Chat':
                            c.title = f"Image: {message[:30] if message else 'Vision'}"
                        c.updated_at = datetime.utcnow()
                        db.session.commit()
                        final_title = c.title
                    else:
                        final_title = conv_title_val

                yield f"data: {_json.dumps({'done': True, 'conv_id': conv_id_val, 'conv_title': final_title, 'mode': 'vision'})}\n\n"

            except Exception as e:
                yield f"data: {_json.dumps({'error': str(e)})}\n\n"

        return Response(
            stream_vision(),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no'
            }
        )

    # ── Image Generation Mode ──
    if is_image_request(message) and not image:
        return handle_image_generation(message, conv, chat_history)

    # ── Text / RAG Streaming Mode ──
    unload_vision_model()

    if doc_chunks:
        smart_chunks = get_smart_chunks(message, doc_chunks)
        prompt = build_prompt(message, smart_chunks)
        if lang_prompt:
            prompt += f"\n\n{lang_prompt}"
    else:
        prompt = message + (f"\n\n{lang_prompt}" if lang_prompt else "")

    chat_history.append({"role": "user", "content": message})
    messages_for_ai = chat_history[:-1] + [
        {"role": "user", "content": prompt}]

    body = {
        "model": TEXT_MODEL,
        "messages": messages_for_ai,
        "stream": True,
        "options": {
            "temperature": 0.7,
            "num_predict": 300,
            "num_ctx": 2048
        }
    }

    conv_id_val = conv.id
    conv_title_val = conv.title
    is_rag = bool(doc_chunks)

    def stream_response():
        answer = ""
        try:
            res = requests.post(
                f"{OLLAMA_URL}/api/chat",
                json=body, stream=True, timeout=120)
            for line in res.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line.decode('utf-8'))
                        token = chunk.get(
                            "message", {}).get("content", "")
                        if token:
                            answer += token
                            yield f"data: {json.dumps({'token': token})}\n\n"
                        if chunk.get("done"):
                            break
                    except:
                        continue

            chat_history.append(
                {"role": "assistant", "content": answer})
            if len(chat_history) > 21:
                chat_history[1:] = chat_history[-20:]

            with app.app_context():
                c = Conversation.query.get(conv_id_val)
                if c:
                    c.set_messages(chat_history)
                    if c.title == 'New Chat' and message:
                        c.title = message[:50] + (
                            '...' if len(message) > 50 else '')
                    c.updated_at = datetime.utcnow()
                    db.session.commit()
                    final_title = c.title
                else:
                    final_title = conv_title_val

            yield f"data: {json.dumps({'done': True, 'conv_id': conv_id_val, 'conv_title': final_title, 'mode': 'rag' if is_rag else 'text'})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return Response(
        stream_response(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no'
        }
    )


# ── Study Tool Routes ──
@app.route('/study/upload', methods=['POST'])
@login_required
def study_upload():
    file = request.files.get('file')
    file_type = request.form.get('type', 'questions')
    if not file:
        return jsonify({'error': 'No file'}), 400
    filename = f"{file_type}_{current_user.id}_{int(time.time())}.pdf"
    path = os.path.join(STUDY_FOLDER, filename)
    file.save(path)
    text = extract_pdf_text(path)
    if not text:
        return jsonify({'error': 'Could not read PDF'}), 500
    return jsonify({
        'success': True,
        'filename': filename,
        'preview': text[:200] + '...' if len(text) > 200 else text,
        'length': len(text)
    })


@app.route('/study/qa', methods=['POST'])
@login_required
def study_qa():
    data = request.json
    questions_file = data.get('questions_file')
    notes_file = data.get('notes_file')
    instruction = data.get('instruction', 'all')
    if not questions_file or not notes_file:
        return jsonify({'error': 'Both files required'}), 400
    q_path = os.path.join(STUDY_FOLDER, questions_file)
    n_path = os.path.join(STUDY_FOLDER, notes_file)
    if not os.path.exists(q_path) or not os.path.exists(n_path):
        return jsonify({'error': 'Files not found'}), 404
    q_text = extract_pdf_text(q_path)
    n_text = extract_pdf_text(n_path)
    if not q_text or not n_text:
        return jsonify({'error': 'Could not read PDFs'}), 500
    result = generate_qa(q_text, n_text, instruction)
    return jsonify(result)


@app.route('/study/quiz', methods=['POST'])
@login_required
def study_quiz():
    data = request.json
    filename = data.get('filename')
    num_q = data.get('num_questions', 10)
    if not filename:
        return jsonify({'error': 'No file'}), 400
    path = os.path.join(STUDY_FOLDER, filename)
    if not os.path.exists(path):
        return jsonify({'error': 'File not found'}), 404
    text = extract_pdf_text(path)
    if not text:
        return jsonify({'error': 'Could not read PDF'}), 500
    result = generate_quiz(text, num_q)
    return jsonify(result)


@app.route('/study/flashcards', methods=['POST'])
@login_required
def study_flashcards():
    data = request.json
    filename = data.get('filename')
    num_cards = data.get('num_cards', 15)
    if not filename:
        return jsonify({'error': 'No file'}), 400
    path = os.path.join(STUDY_FOLDER, filename)
    if not os.path.exists(path):
        return jsonify({'error': 'File not found'}), 404
    text = extract_pdf_text(path)
    if not text:
        return jsonify({'error': 'Could not read PDF'}), 500
    result = generate_flashcards(text, num_cards)
    return jsonify(result)


@app.route('/study/notes', methods=['POST'])
@login_required
def study_notes():
    data = request.json
    filename = data.get('filename')
    topic = data.get('topic', '')
    if not filename:
        return jsonify({'error': 'No file'}), 400
    path = os.path.join(STUDY_FOLDER, filename)
    if not os.path.exists(path):
        return jsonify({'error': 'File not found'}), 404
    text = extract_pdf_text(path)
    if not text:
        return jsonify({'error': 'Could not read PDF'}), 500
    result = generate_smart_notes(text, topic)
    return jsonify(result)


@app.route('/study/math', methods=['POST'])
@login_required
def study_math():
    data = request.json
    problem = data.get('problem', '')
    if not problem:
        return jsonify({'error': 'No problem'}), 400
    result = solve_math(problem)
    return jsonify(result)


@app.route('/study/citation', methods=['POST'])
@login_required
def study_citation():
    data = request.json
    info = data.get('info', '')
    style = data.get('style', 'APA')
    if not info:
        return jsonify({'error': 'No info'}), 400
    result = generate_citation(info, style)
    return jsonify(result)


@app.route('/study/code', methods=['POST'])
@login_required
def study_code():
    data = request.json
    action = data.get('action', 'explain')
    code = data.get('code', '')
    question = data.get('question', '')
    error = data.get('error', '')
    language = data.get('language', 'python')

    # Build prompt based on action
    if action == 'explain':
        system = """You are an expert programming tutor.
Analyze and explain the code clearly.
Format:
OVERVIEW:
[What the code does]

LINE BY LINE:
[Explain each important part]

BUGS FOUND:
[Any errors or issues]

IMPROVEMENTS:
[How to make it better]"""
        user = f"""Code:
```
{code}
```
{"Question: " + question if question else "Explain this code in detail."}"""

    elif action == 'fix':
        system = """You are an expert debugger.
Fix the code and explain what was wrong.
Format:
ISSUE: [what was wrong]

FIXED CODE:
```python
[fixed code]
```

EXPLANATION: [what you changed and why]"""
        user = f"""Fix this code:
```
{code}
```
{"Error: " + error if error else "Find and fix any bugs."}"""

    elif action == 'generate':
        system = f"""You are an expert {language} developer.
Write complete working code with clear comments.
Format:
```{language}
# complete code
```
Then explain what the code does."""
        user = f"Write {language} code for: {question}"

    else:
        return jsonify({'success': False, 'error': 'Unknown action'})

    body = {
        "model": "deepseek-coder:6.7b",
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user}
        ],
        "keep_alive": -1,
        "stream": True,
        "options": {
            "temperature": 0.2,
            "num_predict": 1500,
            "num_ctx": 4096
        }
    }

    def stream_code():
        try:
            res = requests.post(
                f"{OLLAMA_URL}/api/chat",
                json=body,
                stream=True,
                timeout=300
            )
            for line in res.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line.decode('utf-8'))
                        token = chunk.get(
                            "message", {}).get("content", "")
                        if token:
                            yield f"data: {json.dumps({'token': token})}\n\n"
                        if chunk.get("done"):
                            yield f"data: {json.dumps({'done': True})}\n\n"
                            break
                    except:
                        continue
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return Response(
        stream_code(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no'
        }
    )

# ── Upload Routes ──
@app.route('/upload-pdf', methods=['POST'])
@login_required
def upload_pdf():
    global doc_chunks
    file = request.files.get('file')
    if not file:
        return jsonify({'error': 'No file'}), 400
    path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(path)
    chunks, message = load_pdf(path)
    if chunks is None:
        return jsonify({'error': message}), 500
    doc_chunks = chunks
    info = get_doc_info(chunks)
    return jsonify({
        'success': True,
        'message': message,
        'info': info
    })


@app.route('/upload-ebook', methods=['POST'])
@login_required
def upload_ebook():
    global doc_chunks
    file = request.files.get('file')
    if not file:
        return jsonify({'error': 'No file'}), 400
    path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(path)
    chunks, message = load_ebook(path)
    if chunks is None:
        return jsonify({'error': message}), 500
    doc_chunks = chunks
    info = get_doc_info(chunks)
    return jsonify({
        'success': True,
        'message': message,
        'info': info
    })


@app.route('/agent', methods=['POST'])
@login_required
def agent():
    data = request.json
    user_request = data.get('request', '')
    if not user_request:
        return jsonify({'error': 'No request'}), 400
    try:
        result = run_agent(user_request)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/preview-app', methods=['POST'])
@login_required
def preview_app():
    data = request.json
    html_file = data.get('html_file', '')
    if not html_file or not os.path.exists(html_file):
        return jsonify({'error': 'File not found'}), 400
    try:
        with open(html_file, 'r', encoding='utf-8') as f:
            html_content = f.read()
        return jsonify({'html': html_content})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/export-exe', methods=['POST'])
@login_required
def export_exe():
    data = request.json
    project_dir = data.get('project_dir', '')
    app_name = data.get('app_name', 'myapp')
    html_file = os.path.join(project_dir, 'index.html')
    if not os.path.exists(html_file):
        return jsonify({'error': 'index.html not found'}), 400
    try:
        launcher_py = os.path.join(project_dir, 'launcher.py')
        with open(launcher_py, 'w') as f:
            f.write(f'''import webbrowser
import os
html_file = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "index.html")
webbrowser.open(f"file://{{html_file}}")
input("Press Enter to close...")
''')
        dist_dir = os.path.join(project_dir, 'dist')
        result = subprocess.run([
            'pyinstaller', '--onefile', '--name', app_name,
            '--distpath', dist_dir,
            '--workpath', os.path.join(project_dir, 'build'),
            '--specpath', project_dir,
            '--add-data', f'{html_file}:.',
            launcher_py
        ], capture_output=True, text=True, timeout=120)
        exe_path = os.path.join(dist_dir, app_name)
        if os.path.exists(exe_path):
            return jsonify({'success': True, 'exe_path': exe_path})
        return jsonify({
            'error': f'Build failed: {result.stderr[-300:]}'
        }), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/voice', methods=['POST'])
@login_required
def voice():
    audio = request.files.get('audio')
    if not audio:
        return jsonify({'error': 'No audio'}), 400
    audio_path = os.path.join(TEMP_FOLDER, 'voice.wav')
    audio.save(audio_path)
    return jsonify({
        'text': 'Voice received',
        'answer': 'Voice processing coming soon!',
        'mode': 'text'
    })


# ── WebSocket ──
@socketio.on('run_app')
def handle_run_app(data):
    filepath = data.get('filepath', '')
    session_id = data.get('session_id', 'default')
    if not filepath or not os.path.exists(filepath):
        emit('terminal_output', {'data': 'Error: File not found\r\n'})
        return
    emit('terminal_output', {'data': 'Starting app...\r\n'})

    def run_process():
        try:
            master_fd, slave_fd = pty.openpty()
            process = subprocess.Popen(
                ['python3', filepath],
                stdin=slave_fd, stdout=slave_fd,
                stderr=slave_fd, close_fds=True)
            active_processes[session_id] = process
            active_masters[session_id] = master_fd
            os.close(slave_fd)
            while True:
                try:
                    r, _, _ = select.select(
                        [master_fd], [], [], 0.1)
                    if r:
                        output = os.read(
                            master_fd, 1024
                        ).decode('utf-8', errors='replace')
                        socketio.emit(
                            'terminal_output', {'data': output})
                    if process.poll() is not None:
                        socketio.emit('app_finished', {})
                        break
                except OSError:
                    break
            try:
                os.close(master_fd)
            except:
                pass
            active_processes.pop(session_id, None)
            active_masters.pop(session_id, None)
        except Exception as e:
            socketio.emit(
                'terminal_output',
                {'data': f'Error: {str(e)}\r\n'}
            )

    threading.Thread(target=run_process, daemon=True).start()


@socketio.on('terminal_input')
def handle_terminal_input(data):
    session_id = data.get('session_id', 'default')
    input_data = data.get('data', '')
    master_fd = active_masters.get(session_id)
    if master_fd:
        try:
            os.write(master_fd, input_data.encode())
        except Exception as e:
            print(f"Input error: {e}")


@socketio.on('kill_app')
def handle_kill_app(data):
    session_id = data.get('session_id', 'default')
    process = active_processes.get(session_id)
    if process:
        try:
            process.terminate()
        except:
            pass


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("Database ready!")
    print("Starting JANS-HUB Study Hub...")
    print(f"Text model: {TEXT_MODEL}")
    print("Open http://localhost:5000")
    socketio.run(
        app,
        debug=False,
        port=5000,
        allow_unsafe_werkzeug=True
    )