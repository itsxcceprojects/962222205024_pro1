import requests
import re
import fitz

OLLAMA_URL = "http://localhost:11434"
TEXT_MODEL = "gemma3:4b"
CODE_MODEL = "deepseek-coder:6.7b"


# ── Shared Helpers ──

def extract_pdf_text(filepath):
    try:
        doc = fitz.open(filepath)
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()
        return text.strip()
    except Exception as e:
        return None


def split_chunks(text, size=500, overlap=50):
    chunks = []
    for i in range(0, len(text), size - overlap):
        chunk = text[i:i + size]
        if chunk.strip():
            chunks.append(chunk)
    return chunks


def find_relevant(query, chunks, top_k=5):
    words = [w.lower() for w in query.split() if len(w) > 3]
    scored = []
    for chunk in chunks:
        score = sum(1 for w in words if w in chunk.lower())
        scored.append((score, chunk))
    scored.sort(reverse=True)
    return [c for _, c in scored[:top_k]]


def ask_model(system, user, max_tokens=800, model=None):
    if model is None:
        model = TEXT_MODEL
    try:
        res = requests.post(f"{OLLAMA_URL}/api/chat", json={
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user}
            ],
            "keep_alive": -1,
            "stream": False,
            "options": {
                "temperature": 0.2,
                "num_predict": max_tokens,
                "num_ctx": 3000
            }
        }, timeout=120)
        if res.ok:
            return res.json()["message"]["content"].strip()
        return ""
    except Exception as e:
        return f"Error: {str(e)}"


# ── Feature 1: Q&A Generator ──

def extract_questions(text):
    questions = []
    lines = text.split('\n')
    current_q = ""
    patterns = [
        r'^Q\d+[\.\):]',
        r'^\d+[\.\):]',
        r'^\([a-zA-Z0-9]\)',
    ]
    starters = [
        'what', 'why', 'how', 'when', 'where', 'who',
        'which', 'explain', 'describe', 'define', 'discuss',
        'compare', 'differentiate', 'list', 'state', 'write',
        'mention', 'give', 'find', 'calculate', 'prove',
        'show', 'derive', 'evaluate', 'analyse', 'analyze'
    ]
    for line in lines:
        line = line.strip()
        if not line:
            if current_q:
                questions.append(current_q.strip())
                current_q = ""
            continue
        is_new_q = any(re.match(p, line) for p in patterns)
        is_q_word = any(
            line.lower().startswith(w) for w in starters)
        if is_new_q or is_q_word:
            if current_q:
                questions.append(current_q.strip())
            current_q = line
        elif current_q:
            current_q += " " + line
    if current_q:
        questions.append(current_q.strip())
    return [q for q in questions if len(q) > 10]


def is_detail_question(question):
    detail_keywords = [
        'explain', 'describe', 'discuss', 'elaborate',
        'in detail', 'detail', 'analyze', 'analyse',
        'compare', 'differentiate', 'evaluate',
        'derive', 'prove', 'justify', 'illustrate'
    ]
    return any(k in question.lower() for k in detail_keywords)


def parse_filter(instruction, questions):
    instr = instruction.lower()
    range_match = re.search(r'(\d+)\s*(?:to|-)\s*(\d+)', instr)
    single_match = re.search(r'question\s+(\d+)', instr)
    is_all = not range_match and not single_match

    filtered = []
    for i, q in enumerate(questions, 1):
        if range_match:
            s = int(range_match.group(1))
            e = int(range_match.group(2))
            if s <= i <= e:
                filtered.append((i, q))
        elif single_match:
            if i == int(single_match.group(1)):
                filtered.append((i, q))
        elif is_all:
            filtered.append((i, q))
    return filtered if filtered else [
        (i+1, q) for i, q in enumerate(questions)]


def generate_qa(questions_text, notes_text, instruction="all"):
    all_questions = extract_questions(questions_text)
    if not all_questions:
        return {"success": False, "error": "No questions found in PDF"}

    chunks = split_chunks(notes_text)
    filtered = parse_filter(instruction, all_questions)
    qa_pairs = []

    for q_num, question in filtered:
        is_detail = is_detail_question(question)
        relevant = find_relevant(
            question, chunks, top_k=6 if is_detail else 3)
        context = "\n\n".join(relevant)

        if is_detail:
            instr = "Give DETAILED answer. Copy exact phrases from notes. 5-8 sentences minimum."
            max_tok = 500
        else:
            instr = "Give SHORT answer. Copy exact phrases from notes. Max 2-3 sentences only."
            max_tok = 150

        answer = ask_model(
            "You are an exam answer writer. Copy exact text from notes. Never add outside information.",
            f"{instr}\n\nNotes:\n{context}\n\nQuestion: {question}\n\nAnswer:",
            max_tok
        )

        qa_pairs.append({
            "number": q_num,
            "question": question,
            "answer": answer,
            "type": "detail" if is_detail else "short"
        })

    return {
        "success": True,
        "qa_pairs": qa_pairs,
        "total": len(qa_pairs)
    }


# ── Feature 2: Quiz Generator ──

def generate_quiz(pdf_text, num_questions=10):
    chunks = split_chunks(pdf_text)
    step = max(1, len(chunks) // num_questions)
    selected = [chunks[i] for i in
                range(0, len(chunks), step)][:num_questions]
    context = "\n\n".join(selected)

    system = """You are a quiz creator. Generate MCQ questions.
STRICTLY follow this format for EACH question:
Q: [question text here]
A) [option here]
B) [option here]
C) [option here]
D) [option here]
ANS: [A or B or C or D]

Put a blank line between each question.
Do not add any extra text or numbering."""

    user = f"""Generate exactly {num_questions} MCQ questions from this content:

{context}

Remember: Use EXACTLY the format shown. Every question needs Q:, A), B), C), D), ANS:"""

    response = ask_model(system, user, 3000)
    print(f"Quiz raw response preview: {response[:300]}")

    questions = []
    blocks = re.split(r'\n(?=Q:)', response.strip())

    for block in blocks:
        if not block.strip():
            continue
        q_match = re.search(
            r'Q:\s*(.+?)(?=\nA\))', block, re.DOTALL)
        a_match = re.search(
            r'A\)\s*(.+?)(?=\nB\))', block, re.DOTALL)
        b_match = re.search(
            r'B\)\s*(.+?)(?=\nC\))', block, re.DOTALL)
        c_match = re.search(
            r'C\)\s*(.+?)(?=\nD\))', block, re.DOTALL)
        d_match = re.search(
            r'D\)\s*(.+?)(?=\nANS:)', block, re.DOTALL)
        ans_match = re.search(r'ANS:\s*([A-D])', block)

        if q_match and a_match and ans_match:
            questions.append({
                "question": q_match.group(1).strip(),
                "options": {
                    "A": a_match.group(1).strip() if a_match else "",
                    "B": b_match.group(1).strip() if b_match else "",
                    "C": c_match.group(1).strip() if c_match else "",
                    "D": d_match.group(1).strip() if d_match else "",
                },
                "answer": ans_match.group(1).strip()
            })

    print(f"Parsed {len(questions)} questions")

    return {
        "success": bool(questions),
        "questions": questions,
        "total": len(questions),
        "raw": response[:300] if not questions else ""
    }


# ── Feature 3: Flashcard Maker ──

def generate_flashcards(pdf_text, num_cards=15):
    chunks = split_chunks(pdf_text)
    step = max(1, len(chunks) // num_cards)
    selected = [chunks[i] for i in
                range(0, len(chunks), step)][:num_cards]
    context = "\n\n".join(selected)

    system = """You are a flashcard creator for students.
Create flashcards from the content.
Format EXACTLY like this:
FRONT: [term or concept]
BACK: [definition or explanation]
---
Each card separated by ---"""

    user = f"""Content:
{context}

Create {num_cards} flashcards focusing on key terms and concepts."""

    response = ask_model(system, user, 2000)
    cards = []
    blocks = response.split('---')

    for block in blocks:
        front_match = re.search(r'FRONT:\s*(.+)', block)
        back_match = re.search(
            r'BACK:\s*(.+?)(?=FRONT:|$)', block, re.DOTALL)
        if front_match and back_match:
            cards.append({
                "front": front_match.group(1).strip(),
                "back": back_match.group(1).strip()
            })

    return {
        "success": bool(cards),
        "cards": cards,
        "total": len(cards)
    }


# ── Feature 4: Smart Notes ──

def generate_smart_notes(pdf_text, topic=""):
    chunks = split_chunks(pdf_text)
    if topic:
        selected = find_relevant(topic, chunks, top_k=8)
    else:
        step = max(1, len(chunks) // 10)
        selected = [chunks[i] for i in
                    range(0, len(chunks), step)][:10]
    context = "\n\n".join(selected)

    system = """You are a smart notes creator for students.
Create well-structured study notes.
Use this format:
# [Main Topic]
## Key Concepts
- Important point 1
- Important point 2
## Definitions
- Term: Definition
## Summary
Brief summary paragraph
Make notes clear, concise and easy to study."""

    user = f"""Content:
{context}

{"Focus on topic: " + topic if topic else "Create comprehensive study notes."}"""

    notes = ask_model(system, user, 1500)
    return {"success": True, "notes": notes}


# ── Feature 5: Math Solver ──

def solve_math(problem):
    system = """You are an expert math tutor.
Solve step by step clearly.
Format:
PROBLEM: [restate problem]

SOLUTION:
Step 1: [explanation]
Step 2: [explanation]
Step 3: [explanation]

ANSWER: [final answer]

Explain every step clearly for a student."""

    solution = ask_model(
        system,
        f"Solve this step by step:\n{problem}",
        800
    )
    return {
        "success": True,
        "solution": solution,
        "problem": problem
    }


# ── Feature 6: Citation Generator ──

def generate_citation(info, style="APA"):
    styles_info = {
        "APA": "Author, A. A. (Year). Title of work. Publisher.",
        "MLA": "Author Last, First. Title of Work. Publisher, Year.",
        "Chicago": "Author Last, First. Title. City: Publisher, Year."
    }

    system = f"You are a citation formatter. Generate ONLY the {style} citation. No extra text."
    user = f"""Generate {style} citation for:
{info}

Format: {styles_info.get(style, '')}
Return ONLY the formatted citation."""

    citation = ask_model(system, user, 200)
    return {
        "success": True,
        "citation": citation,
        "style": style
    }


# ── Feature 7: Code Tutor (DeepSeek) ──

def explain_code(code, question=""):
    system = """You are an expert programming tutor.
Analyze and explain the code clearly.
Format:
OVERVIEW:
[What the code does]

LINE BY LINE:
[Explain each important part]

BUGS FOUND:
[Any errors or issues]

IMPROVEMENTS:
[How to make it better]"""

    user = f"""Code:
```
{code}
```
{"Question: " + question if question else "Explain this code in detail for a student."}"""

    try:
        res = requests.post(f"{OLLAMA_URL}/api/chat", json={
            "model": CODE_MODEL,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user}
            ],
            "keep_alive": -1,
            "stream": False,
            "options": {
                "temperature": 0.2,
                "num_predict": 1000,
                "num_ctx": 4096
            }
        }, timeout=120)
        if res.ok:
            return {
                "success": True,
                "explanation": res.json()[
                    "message"]["content"].strip()
            }
        return {"success": False, "error": "Model error"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def fix_code(code, error=""):
    system = """You are an expert debugger.
Fix the code and explain what was wrong.
Format:
ISSUE: [what was wrong]

FIXED CODE:
```python
[fixed code]
```

EXPLANATION: [what you changed and why]"""

    user = f"""Fix this code:
```
{code}
```
{"Error: " + error if error else "Find and fix any bugs."}"""

    try:
        res = requests.post(f"{OLLAMA_URL}/api/chat", json={
            "model": CODE_MODEL,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user}
            ],
            "keep_alive": -1,
            "stream": False,
            "options": {
                "temperature": 0.1,
                "num_predict": 1000,
                "num_ctx": 4096
            }
        }, timeout=120)
        if res.ok:
            return {
                "success": True,
                "result": res.json()[
                    "message"]["content"].strip()
            }
        return {"success": False, "error": "Model error"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def generate_code(description, language="python"):
    system = f"""You are an expert {language} developer.
Write complete working code with clear comments.
Format:
```{language}
# complete code
```
Then explain what the code does."""

    try:
        res = requests.post(f"{OLLAMA_URL}/api/chat", json={
            "model": CODE_MODEL,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": f"Write {language} code for: {description}"}
            ],
            "keep_alive": -1,
            "stream": False,
            "options": {
                "temperature": 0.2,
                "num_predict": 1500,
                "num_ctx": 4096
            }
        }, timeout=120)
        if res.ok:
            return {
                "success": True,
                "result": res.json()[
                    "message"]["content"].strip()
            }
        return {"success": False, "error": "Model error"}
    except Exception as e:
        return {"success": False, "error": str(e)}